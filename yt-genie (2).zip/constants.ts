import { FilterOption, Language, AspectRatio, AdjustmentTool, EffectTool, TransformTool, DecorationTool, AiSmartTool } from './types';    
import React from 'react'; // Import React for JSX in tool definitions and React.createElement

// Simple placeholder icons (replace with actual SVGs or a library in a real app)
const PlaceholderIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🖼️'); // Changed emoji
const BrightnessIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '☀️');
const ContrastIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '◑');
const SaturationIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🎨');
const TemperatureIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🌡️');
const EffectsIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '✨');
const TransformIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🔄');
const TextIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, ' Tt '); // Updated text
const StickerIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '😊');
const FrameIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🖼️');
const MagicWandIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🪄');


export const APP_NAME = "YT Genie";
export const NUMBER_OF_IMAGES_TO_GENERATE = 4;

export const MOCK_VIDEO_URL_PREFIX = "https://www.youtube.com/watch?v=";
export const MOCK_THUMBNAIL_BASE_URL = "https://i.ytimg.com/vi/"; 
export const PLACEHOLDER_IMAGE_URL = "https://picsum.photos/seed/ytgenieplaceholder/480/360"; 

export const AVAILABLE_LANGUAGES: Language[] = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
];

// Note: While Imagen API might accept various string formats, these are common and testable.
// The Imagen API might have specific supported ratios or might try its best to match.
export const AVAILABLE_ASPECT_RATIOS: { label: string, value: AspectRatio }[] = [
  { label: 'Widescreen (16:9)', value: AspectRatio.WIDESCREEN },
  { label: 'Square (1:1)', value: AspectRatio.SQUARE },
  { label: 'Portrait (9:16)', value: AspectRatio.PORTRAIT },
  { label: 'Landscape (4:3)', value: AspectRatio.LANDSCAPE_4_3 },
  { label: 'Landscape (3:2)', value: AspectRatio.LANDSCAPE_3_2 },
];

export const EDITOR_FILTERS: FilterOption[] = [
  { id: 'grayscale', name: 'Grayscale', cssClass: 'grayscale' },
  { id: 'sepia', name: 'Sepia', cssClass: 'sepia' },
  { id: 'saturate', name: 'Saturate', cssClass: 'saturate-150' },
  { id: 'contrast', name: 'Contrast', cssClass: 'contrast-125' },
  { id: 'brightness', name: 'Brighten', cssClass: 'brightness-110' },
  { id: 'invert', name: 'Invert', cssClass: 'invert'},
  { id: 'hue-rotate-90', name: 'Hue Rotate 90', cssClass: 'hue-rotate-90'},
];

export const TEXT_FONTS = ['Arial', 'Verdana', 'Times New Roman', 'Courier New', 'Georgia', 'Comic Sans MS', 'Impact', 'Roboto', 'Montserrat'];

// Mock Editor Tools Definitions
const commonToolClass = "w-full text-left p-2 text-sm rounded hover:bg-primary/10 dark:hover:bg-primary-dark/20 flex items-center gap-2";

export const MOCK_ADJUSTMENT_TOOLS: AdjustmentTool[] = [
  { id: 'brightness', name: 'Brightness', icon: React.createElement(BrightnessIcon, { className: "h-4 w-4"}), actionType: 'adjustment_brightness' },
  { id: 'contrast', name: 'Contrast', icon: React.createElement(ContrastIcon, { className: "h-4 w-4"}), actionType: 'adjustment_contrast' },
  { id: 'saturation', name: 'Saturation', icon: React.createElement(SaturationIcon, { className: "h-4 w-4"}), actionType: 'adjustment_saturation' },
  { id: 'exposure', name: 'Exposure', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'adjustment_exposure' },
  { id: 'highlights', name: 'Highlights', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'adjustment_highlights' },
  { id: 'shadows', name: 'Shadows', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'adjustment_shadows' },
  { id: 'temperature', name: 'Temperature', icon: React.createElement(TemperatureIcon, { className: "h-4 w-4"}), actionType: 'adjustment_temperature' },
  { id: 'tint', name: 'Tint', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'adjustment_tint' },
];

export const MOCK_EFFECT_TOOLS: EffectTool[] = [
  { id: 'blur', name: 'Gaussian Blur', icon: React.createElement(EffectsIcon, { className: "h-4 w-4"}), actionType: 'effect_blur' },
  { id: 'sharpen', name: 'Sharpen', icon: React.createElement(EffectsIcon, { className: "h-4 w-4"}), actionType: 'effect_sharpen' },
  { id: 'pixelate', name: 'Pixelate', icon: React.createElement(EffectsIcon, { className: "h-4 w-4"}), actionType: 'effect_pixelate' },
  { id: 'vignette', name: 'Vignette', icon: React.createElement(EffectsIcon, { className: "h-4 w-4"}), actionType: 'effect_vignette' },
  { id: 'duotone', name: 'Duotone', icon: React.createElement(EffectsIcon, { className: "h-4 w-4"}), actionType: 'effect_duotone' },
];

export const MOCK_TRANSFORM_TOOLS: TransformTool[] = [
  { id: 'rotate_left', name: 'Rotate Left 90°', icon: React.createElement(TransformIcon, { className: "h-4 w-4"}), actionType: 'transform_rotate_left' },
  { id: 'rotate_right', name: 'Rotate Right 90°', icon: React.createElement(TransformIcon, { className: "h-4 w-4"}), actionType: 'transform_rotate_right' },
  { id: 'flip_horizontal', name: 'Flip Horizontal', icon: React.createElement(TransformIcon, { className: "h-4 w-4"}), actionType: 'transform_flip_horizontal' },
  { id: 'flip_vertical', name: 'Flip Vertical', icon: React.createElement(TransformIcon, { className: "h-4 w-4"}), actionType: 'transform_flip_vertical' },
  { id: 'crop', name: 'Crop Image', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'transform_crop' },
  { id: 'resize', name: 'Resize Image', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'transform_resize' },
];

export const MOCK_DECORATION_TOOLS: DecorationTool[] = [
  { id: 'add_sticker', name: 'Add Sticker', icon: React.createElement(StickerIcon, { className: "h-4 w-4"}), actionType: 'decoration_sticker' },
  { id: 'add_shape', name: 'Add Shape', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'decoration_shape' },
  { id: 'add_frame', name: 'Add Frame', icon: React.createElement(FrameIcon, { className: "h-4 w-4"}), actionType: 'decoration_frame' },
  { id: 'draw_tool', name: 'Draw Tool', icon: React.createElement(PlaceholderIcon, { className: "h-4 w-4"}), actionType: 'decoration_draw' },
];

export const MOCK_AI_SMART_TOOLS: AiSmartTool[] = [
  { id: 'ai_upscale', name: 'AI Upscale Image', icon: React.createElement(MagicWandIcon, { className: "h-4 w-4"}), actionType: 'ai_smart_upscale' },
  { id: 'ai_object_remove', name: 'AI Object Remove', icon: React.createElement(MagicWandIcon, { className: "h-4 w-4"}), actionType: 'ai_smart_object_remove' },
  { id: 'ai_bg_replace', name: 'AI Smart BG Replace', icon: React.createElement(MagicWandIcon, { className: "h-4 w-4"}), actionType: 'ai_smart_bg_replace' },
  { id: 'ai_auto_enhance', name: 'AI Auto Enhance', icon: React.createElement(MagicWandIcon, { className: "h-4 w-4"}), actionType: 'ai_smart_auto_enhance' },
  { id: 'ai_smart_crop', name: 'AI Smart Crop', icon: React.createElement(MagicWandIcon, { className: "h-4 w-4"}), actionType: 'ai_smart_crop' },
];