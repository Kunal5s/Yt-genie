
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SearchBar } from './components/SearchBar';
import { VideoPreview } from './components/VideoPreview';
import { ThumbnailDownloader } from './components/ThumbnailDownloader';
import { AudioDownloader } from './components/AudioDownloader';
import { AiImageGeneratorControls } from './components/AiThumbnailGenerator';
import { ThumbnailEditor } from './components/ThumbnailEditor';
import { SeoContentGenerator } from './components/SeoContentGenerator';
import { TrendingThumbnails } from './components/TrendingThumbnails';
import { FeedbackForm } from './components/FeedbackForm';
import { SocialShare } from './components/SocialShare';
import { useDarkMode } from './hooks/useDarkMode';
import { VideoInfo, GeneratedContent, TextOverlayOptions, AspectRatio, GeneratedImageDetail } from './types';
import { fetchVideoInfo as mockFetchVideoInfo } from './services/youtubeService';
import { 
  generateImageFromText,
  generateSeoContent, // Using live AI now
  applyMockEdit 
} from './services/geminiService';
import { PLACEHOLDER_IMAGE_URL, AVAILABLE_ASPECT_RATIOS, APP_NAME, NUMBER_OF_IMAGES_TO_GENERATE } from './constants';

// Icons for generated image actions
const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);
const EditIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
  </svg>
);


const App: React.FC = () => {
  const [darkMode, toggleDarkMode] = useDarkMode();
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [currentThumbnail, setCurrentThumbnail] = useState<string>(PLACEHOLDER_IMAGE_URL);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('Processing...');
  const [error, setError] = useState<string | null>(null);
  const [seoContent, setSeoContent] = useState<GeneratedContent | null>(null);
  const [showEditor, setShowEditor] = useState<boolean>(false);
  const [showFeedbackForm, setShowFeedbackForm] = useState<boolean>(false);
  
  const [imagePrompt, setImagePrompt] = useState<string>('');
  const [userSeoPrompt, setUserSeoPrompt] = useState<string>(''); // New state for SEO user input
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>(AVAILABLE_ASPECT_RATIOS[0].value);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImageDetail[]>([]);

  const [textOverlay, setTextOverlay] = useState<TextOverlayOptions>({ text: 'Your Text Here', font: 'Arial', color: '#FFFFFF', size: 24, position: { x: 10, y: 90 } });
  const [activeFilter, setActiveFilter] = useState<string>('');

  const resetToInitialState = () => {
    setYoutubeUrl('');
    setVideoInfo(null);
    setCurrentThumbnail(PLACEHOLDER_IMAGE_URL);
    setError(null);
    setSeoContent(null);
    setShowEditor(false);
    setImagePrompt('');
    setUserSeoPrompt('');
    setGeneratedImages([]);
  };

  const handleSearch = useCallback(async (url: string) => {
    if (!url) {
      setError("Please enter a YouTube video URL.");
      setVideoInfo(null);
      setSeoContent(null); 
      return;
    }
    setIsLoading(true);
    setLoadingMessage('Fetching video information...');
    setError(null);
    setSeoContent(null); 
    setShowEditor(false);
    try {
      const info = await mockFetchVideoInfo(url);
      setVideoInfo(info);
      setCurrentThumbnail(info.thumbnailUrl); 
      setYoutubeUrl(url); 
      if (info.title && !imagePrompt) { 
        setImagePrompt(`Create a captivating YouTube thumbnail for a video titled: "${info.title}"`);
      }
      if (info.title && !userSeoPrompt) { // Also set userSeoPrompt if empty
        setUserSeoPrompt(info.title);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch video info.");
      setVideoInfo(null);
      if (currentThumbnail.startsWith('https://i.ytimg.com/')) {
          setCurrentThumbnail(PLACEHOLDER_IMAGE_URL);
      }
    } finally {
      setIsLoading(false);
    }
  }, [imagePrompt, currentThumbnail, userSeoPrompt]);

  const handleImageError = useCallback((fallbackUrl: string) => {
    console.warn("Original thumbnail failed to load, switching to fallback:", fallbackUrl);
    setCurrentThumbnail(fallbackUrl);
  },[]);

  const handleGenerateImageFromText = useCallback(async (prompt: string, aspectRatio: AspectRatio) => {
    if (!prompt.trim()) {
      setError("Please enter a prompt for AI image generation.");
      return;
    }
    setIsLoading(true);
    setLoadingMessage(`Generating ${NUMBER_OF_IMAGES_TO_GENERATE} AI images...`);
    setError(null);
    setGeneratedImages([]); 
    try {
      const aiGeneratedImageDetails = await generateImageFromText(prompt, aspectRatio);
      setGeneratedImages(aiGeneratedImageDetails);
      if (aiGeneratedImageDetails.length > 0) {
        // User selects image from gallery now
      } else {
        setError("AI generation returned no images. Please try a different prompt or check API status.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate AI images. Ensure API Key is valid and Imagen API is enabled.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSelectGeneratedImageForEditing = (imageUrl: string) => {
    setCurrentThumbnail(imageUrl);
    setShowEditor(false); 
    if (!userSeoPrompt && imagePrompt){ // If user SEO prompt is empty, use image prompt
        setUserSeoPrompt(imagePrompt);
    }
     const mainPreviewArea = document.getElementById('main-preview-area');
     if (mainPreviewArea) {
        mainPreviewArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
     } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
     }
  };

  const downloadGeneratedImage = (imageUrl: string, prompt: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    const safePrompt = prompt.substring(0, 30).replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'ai_image';
    link.download = `${safePrompt}_${index + 1}.jpeg`; 
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateSeo = useCallback(async () => {
    const contextForSeo = userSeoPrompt.trim() || videoInfo?.title || imagePrompt.trim();

    if (!contextForSeo) {
       setError("Please provide a topic/idea, load a video, or generate an image to create context for SEO content.");
       return;
    }

    setIsLoading(true);
    setLoadingMessage('Generating SEO content with AI...');
    setError(null);
    setSeoContent(null);
    try {
      const content = await generateSeoContent(contextForSeo); // Use live AI service
      setSeoContent(content);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate SEO content. Check API Key and Gemini API settings.");
    } finally {
      setIsLoading(false);
    }
  }, [videoInfo, imagePrompt, userSeoPrompt]);

  const handleEditThumbnail = () => {
    if (currentThumbnail !== PLACEHOLDER_IMAGE_URL) {
      setShowEditor(true);
    } else {
      setError("Please load or generate a thumbnail to edit.");
    }
  };

  const handleApplyTextOverlay = useCallback(async (options: TextOverlayOptions) => {
    setTextOverlay(options);
    await applyMockEdit(currentThumbnail, `text: ${options.text}, font: ${options.font}, color: ${options.color}, size: ${options.size}`);
    alert(`Text overlay "${options.text}" applied (mock).`);
  }, [currentThumbnail]);

  const handleApplyFilter = useCallback(async (filterId: string, filterCssClass: string) => {
    setActiveFilter(filterCssClass);
    await applyMockEdit(currentThumbnail, `filter: ${filterId}`);
    alert(`Filter "${filterId}" applied (mock).`);
  }, [currentThumbnail]);

  const handleApplyMockEditTool = useCallback(async (toolName: string, toolActionType: string) => {
    setIsLoading(true);
    setLoadingMessage(`Applying ${toolName}...`);
    try {
      const newImage = await applyMockEdit(currentThumbnail, `tool: ${toolName}, action: ${toolActionType}`);
      alert(`Mock Tool: "${toolName}" applied.`);
    } catch(err) {
      setError(err instanceof Error ? err.message : `Failed to apply ${toolName}.`);
    } finally {
      setIsLoading(false);
    }
  }, [currentThumbnail]);
  
  const showWelcomeMessage = !videoInfo && !isLoading && generatedImages.length === 0 && currentThumbnail === PLACEHOLDER_IMAGE_URL && !error && !userSeoPrompt;


  return (
    <div className={`min-h-screen flex flex-col ${darkMode ? 'dark' : ''}`}>
      <Header darkMode={darkMode} toggleDarkMode={toggleDarkMode} onShowFeedback={() => setShowFeedbackForm(true)} />
      
      <main className="flex-grow container mx-auto px-4 py-8 space-y-8 sm:space-y-12">
        
        {showWelcomeMessage && (
          <section id="welcome-yt-genie" className="text-center py-10 px-4 bg-gradient-to-br from-primary/10 to-secondary/10 dark:from-primary-dark/20 dark:to-secondary-dark/20 rounded-xl shadow-2xl animate-fade-in">
            <h1 className="text-4xl sm:text-5xl font-extrabold mb-6">
              Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">{APP_NAME}</span>!
            </h1>
            <p className="text-lg sm:text-xl text-neutral-dark dark:text-neutral-light max-w-3xl mx-auto mb-8">
              Your ultimate AI-powered toolkit for YouTube success. Effortlessly download thumbnails, generate stunning, unique images with Google Imagen, edit like a pro, and craft SEO-perfect titles & descriptions.
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto text-left mb-10">
              <div className="p-6 bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-primary-dark dark:text-primary-light mb-2">🎬 Thumbnail Downloader</h3>
                <p className="text-sm text-neutral-dark dark:text-neutral-light">Instantly grab high-quality thumbnails from any YouTube video.</p>
              </div>
              <div className="p-6 bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-accent dark:text-accent-light mb-2">✨ AI Image Generation</h3>
                <p className="text-sm text-neutral-dark dark:text-neutral-light">Powered by Google Imagen: Create {NUMBER_OF_IMAGES_TO_GENERATE} unique, high-quality images from text prompts. Perfect for custom thumbnails!</p>
              </div>
              <div className="p-6 bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-lg shadow-lg">
                <h3 className="text-xl font-semibold text-secondary-dark dark:text-secondary-light mb-2">🛠️ Advanced Editor</h3>
                <p className="text-sm text-neutral-dark dark:text-neutral-light">Crop, resize, filter, add text, stickers, and use AI smart tools (mock) for pixel-perfect edits.</p>
              </div>
               <div className="p-6 bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-lg shadow-lg md:col-span-2 lg:col-span-1 lg:col-start-2">
                <h3 className="text-xl font-semibold text-yellow-500 dark:text-yellow-400 mb-2">📈 SEO Content Generator</h3>
                <p className="text-sm text-neutral-dark dark:text-neutral-light">Automatically create catchy titles, descriptions, tags, and keywords to boost your video's ranking.</p>
              </div>
            </div>
            <p className="text-md text-neutral-dark dark:text-neutral-light">Start by pasting a YouTube URL below, or dive straight into AI Image Generation or SEO Tools!</p>
          </section>
        )}

        <section id="youtube-url-search" className="animate-fade-in">
          <SearchBar onSearch={handleSearch} isLoading={isLoading && loadingMessage.includes('Fetching video')} />
          {error && <p className="mt-4 text-red-500 dark:text-red-400 text-center text-sm shadow-md rounded p-3 bg-red-100 dark:bg-red-900/30">{error}</p>}
        </section>

        {isLoading && (
          <div className="flex flex-col justify-center items-center py-10">
            <div className={`animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary ${loadingMessage.includes("AI images") || loadingMessage.includes("SEO content") ? 'animate-pulse-fast' :''}`}></div>
            <p className="ml-4 mt-4 text-lg text-neutral-dark dark:text-neutral-light">{loadingMessage}</p>
          </div>
        )}
        
        {(!isLoading && (videoInfo || (currentThumbnail !== PLACEHOLDER_IMAGE_URL && !videoInfo && generatedImages.length > 0 ))) && (
            <section id="main-preview-area" className="animate-slide-up bg-white dark:bg-neutral-dark/70 backdrop-blur-md p-6 rounded-xl shadow-xl max-w-3xl mx-auto">
                {videoInfo ? (
                    <VideoPreview 
                        videoInfo={videoInfo} 
                        currentThumbnail={currentThumbnail} 
                        onImageError={handleImageError} 
                    />
                ) : (
                    <div className="text-center">
                        <h2 className="text-2xl font-semibold text-primary-dark dark:text-primary-light mb-4">Selected Image Preview</h2>
                        <img 
                            src={currentThumbnail} 
                            alt="Selected AI image" 
                            className="w-full aspect-video object-contain rounded-lg shadow-md bg-gray-200 dark:bg-gray-700"
                            onError={(e) => { (e.target as HTMLImageElement).src = PLACEHOLDER_IMAGE_URL; }}
                        />
                    </div>
                )}
                <div className="mt-6 space-y-4">
                    {videoInfo && (
                        <>
                            <ThumbnailDownloader videoInfo={videoInfo} currentThumbnailUrl={currentThumbnail} />
                            <AudioDownloader videoInfo={videoInfo} />
                        </>
                    )}
                    {currentThumbnail !== PLACEHOLDER_IMAGE_URL && (
                        <button 
                            onClick={handleEditThumbnail}
                            disabled={isLoading}
                            className="w-full bg-accent hover:bg-accent-dark text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                            <EditIcon className="h-5 w-5"/> Edit This Image
                        </button>
                    )}
                </div>
            </section>
        )}

        <section id="ai-image-studio-section" className={`py-6 animate-fade-in ${(isLoading && !loadingMessage.includes("AI images")) ? 'opacity-60 pointer-events-none' : ''}`}>
            <div className="max-w-3xl mx-auto bg-white dark:bg-neutral-dark/70 backdrop-blur-md p-6 rounded-xl shadow-xl">
                <h2 className="text-2xl sm:text-3xl font-bold text-primary-dark dark:text-primary-light mb-6 text-center">
                    <span role="img" aria-label="sparkles" className="mr-2">✨</span> AI Image Generation Studio
                </h2>
                <AiImageGeneratorControls
                  prompt={imagePrompt}
                  onPromptChange={setImagePrompt}
                  aspectRatio={selectedAspectRatio}
                  onAspectRatioChange={setSelectedAspectRatio}
                  onGenerate={handleGenerateImageFromText}
                  isLoading={isLoading && loadingMessage.includes("AI images")}
                />
            </div>
        </section>
        
        {generatedImages.length > 0 && !isLoading && (
          <section id="ai-generated-gallery" className="animate-slide-up mt-2 mb-6">
            <h2 className="text-2xl font-bold text-center mb-6 text-primary-dark dark:text-primary-light">
              Your AI Generated Images ({generatedImages.length} variants)
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {generatedImages.map((img, index) => (
                <div key={img.id} className="bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-xl shadow-xl overflow-hidden group p-3">
                  <div className="aspect-video rounded-md overflow-hidden mb-3">
                    <img src={img.url} alt={`AI Generated Image ${index + 1}`} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                  </div>
                  <div className="space-y-2">
                    <button
                      onClick={() => downloadGeneratedImage(img.url, imagePrompt, index)}
                      className="w-full flex items-center justify-center gap-2 text-sm bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-3 rounded-md transition-colors"
                      title="Download this image"
                    >
                      <DownloadIcon className="h-4 w-4"/> Download
                    </button>
                    <button
                      onClick={() => handleSelectGeneratedImageForEditing(img.url)}
                      className="w-full flex items-center justify-center gap-2 text-sm bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-3 rounded-md transition-colors"
                      title="Select this image for main preview and editing"
                    >
                     <EditIcon className="h-4 w-4"/> Preview & Edit
                    </button>
                  </div>
                </div>
              ))}
            </div>
             <p className="text-center text-xs text-gray-500 dark:text-gray-400 mt-4">Click 'Preview & Edit' to make an image your main preview and enable editing for it.</p>
          </section>
        )}

        <section id="seo-tools-section" className={`py-6 animate-fade-in ${(isLoading && !loadingMessage.includes("SEO")) ? 'opacity-60 pointer-events-none' : ''}`}>
            <div className="max-w-3xl mx-auto bg-white dark:bg-neutral-dark/70 backdrop-blur-md p-6 rounded-xl shadow-xl">
                <SeoContentGenerator 
                    userPrompt={userSeoPrompt}
                    onUserPromptChange={setUserSeoPrompt}
                    onGenerate={handleGenerateSeo} 
                    generatedContent={seoContent} 
                    isLoading={isLoading && loadingMessage.includes("SEO")} 
                    contextPrompt={userSeoPrompt || videoInfo?.title || imagePrompt}
                />
            </div>
        </section>

        {showEditor && (
          <section id="thumbnail-editor-modal" className="animate-slide-up">
             <ThumbnailEditor
              imageUrl={currentThumbnail}
              onClose={() => setShowEditor(false)}
              textOverlayOptions={textOverlay}
              onTextOverlayChange={handleApplyTextOverlay}
              currentFilterCss={activeFilter}
              onApplyFilter={handleApplyFilter}
              onApplyMockEditTool={handleApplyMockEditTool} 
            />
          </section>
        )}
        
        <TrendingThumbnails />
        <SocialShare videoUrl={youtubeUrl} videoTitle={videoInfo?.title} />

      </main>
      
      {showFeedbackForm && <FeedbackForm onClose={() => setShowFeedbackForm(false)} />}
      <Footer />
    </div>
  );
};

export default App;