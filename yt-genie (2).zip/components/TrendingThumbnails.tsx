
import React from 'react';
import { PLACEHOLDER_IMAGE_URL } from '../constants';

interface TrendingItem {
  id: string;
  title: string;
  imageUrl: string;
  views: string; // e.g., "1.2M views"
}

const mockTrendingItems: TrendingItem[] = [
  { id: 'trend1', title: 'Viral Challenge Gone Wrong!', imageUrl: `https://picsum.photos/seed/trend1/320/180`, views: '2.5M' },
  { id: 'trend2', title: 'My Insane New Gaming Setup', imageUrl: `https://picsum.photos/seed/trend2/320/180`, views: '1.8M' },
  { id: 'trend3', title: 'React Tutorial for Beginners 2024', imageUrl: `https://picsum.photos/seed/trend3/320/180`, views: '980K' },
  { id: 'trend4', title: 'Unboxing the Latest Gadget', imageUrl: `https://picsum.photos/seed/trend4/320/180`, views: '1.1M' },
];


export const TrendingThumbnails: React.FC = () => {
  return (
    <section id="trending" className="py-8">
      <h2 className="text-3xl font-bold text-center mb-8 text-primary-dark dark:text-primary-light">
        🔥 Trending Thumbnail Styles (Inspiration)
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {mockTrendingItems.map(item => (
          <div key={item.id} className="bg-white dark:bg-neutral-dark/70 backdrop-blur-md rounded-xl shadow-xl overflow-hidden group transform transition-all duration-300 hover:scale-105 hover:shadow-2xl">
            <div className="aspect-video">
              <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
            </div>
            <div className="p-4">
              <h3 className="text-md font-semibold text-neutral-dark dark:text-neutral-light truncate group-hover:text-primary-dark dark:group-hover:text-primary-light">{item.title}</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400">{item.views} views</p>
            </div>
          </div>
        ))}
      </div>
       <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
        Note: These are placeholder images for inspirational trending styles.
      </p>
    </section>
  );
};