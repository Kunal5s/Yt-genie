
import React from 'react';
import { VideoInfo, AudioFormat } from '../types';

interface AudioDownloaderProps {
  videoInfo: VideoInfo;
}

const MusicNoteIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
  </svg>
);

export const AudioDownloader: React.FC<AudioDownloaderProps> = ({ videoInfo }) => {
  const handleDownload = (format: AudioFormat) => {
    // This is a MOCK. Actual audio downloading requires a backend service.
    alert(`Mock Download: Audio for "${videoInfo.title}" as ${format.toUpperCase()}. This feature requires a backend service not implemented in this demo.`);
  };

  return (
    <div className="p-4 bg-neutral-light/30 dark:bg-gray-700/30 rounded-lg shadow">
      <h3 className="text-lg font-semibold text-neutral-dark dark:text-neutral-light mb-3">Download Audio (Mock)</h3>
      <button
        onClick={() => handleDownload(AudioFormat.MP3)}
        className="w-full inline-flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
      >
        <MusicNoteIcon className="h-5 w-5" /> MP3
      </button>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Note: Actual audio extraction requires server-side processing and is not implemented in this frontend demo.</p>
    </div>
  );
};
