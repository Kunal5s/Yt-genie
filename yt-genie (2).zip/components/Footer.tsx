
import React from 'react';
import { APP_NAME } from '../constants';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-neutral-dark/90 dark:bg-black/90 text-neutral-light/80 dark:text-gray-400 py-8 text-center">
      <div className="container mx-auto px-4">
        <p className="text-sm">&copy; {new Date().getFullYear()} {APP_NAME}. All Rights Reserved (Mock). </p>
        <p className="text-xs mt-2">
          This is a conceptual application for demonstration purposes. 
          Actual YouTube downloading/modification may violate terms of service.
        </p>
        <div className="mt-3 space-x-4">
          <a href="#privacy" className="hover:text-primary-light text-xs">Privacy Policy (Mock)</a>
          <a href="#terms" className="hover:text-primary-light text-xs">Terms of Service (Mock)</a>
        </div>
      </div>
    </footer>
  );
};
