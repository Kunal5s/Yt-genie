
import React, { useState, useEffect } from 'react';
import { TextOverlayOptions, FilterOption } from '../types';
import { EDITOR_FILTERS, TEXT_FONTS } from '../constants';

interface ThumbnailEditorProps {
  imageUrl: string;
  onClose: () => void;
  textOverlayOptions: TextOverlayOptions;
  onTextOverlayChange: (options: TextOverlayOptions) => void;
  currentFilterCss: string;
  onApplyFilter: (filterId: string, filterCss: string) => void;
  // FIX: Added onApplyMockEditTool prop to match usage in App.tsx
  onApplyMockEditTool: (toolName: string, toolActionType: string) => Promise<void>;
}

const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const CropIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" >
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 3.75H6A2.25 2.25 0 0 0 3.75 6v1.5M16.5 3.75H18A2.25 2.25 0 0 1 20.25 6v1.5m0 9V18A2.25 2.25 0 0 1 18 20.25h-1.5m-9 0H6A2.25 2.25 0 0 1 3.75 18v-1.5M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
  </svg>
);

const ResizeIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75v4.5m0-4.5h-4.5m4.5 0L15 9m5.25 11.25v-4.5m0 4.5h-4.5m4.5 0L15 15" />
  </svg>
);


export const ThumbnailEditor: React.FC<ThumbnailEditorProps> = ({ 
    imageUrl, onClose, textOverlayOptions, onTextOverlayChange, currentFilterCss, onApplyFilter, onApplyMockEditTool
}) => {
  const [localText, setLocalText] = useState(textOverlayOptions.text);
  const [localFont, setLocalFont] = useState(textOverlayOptions.font);
  const [localColor, setLocalColor] = useState(textOverlayOptions.color);
  const [localSize, setLocalSize] = useState(textOverlayOptions.size);

  useEffect(() => {
    setLocalText(textOverlayOptions.text);
    setLocalFont(textOverlayOptions.font);
    setLocalColor(textOverlayOptions.color);
    setLocalSize(textOverlayOptions.size);
  }, [textOverlayOptions]);

  const handleApplyText = () => {
    onTextOverlayChange({ 
        text: localText, 
        font: localFont, 
        color: localColor, 
        size: localSize,
        position: textOverlayOptions.position // Position not editable in this simplified UI
    });
  };
  
  const handleMockAction = (actionName: string, actionType?: string) => {
    if (actionType && onApplyMockEditTool) {
        onApplyMockEditTool(actionName, actionType);
    } else {
        alert(`Mock Action: ${actionName}. Full implementation is complex and beyond this demo's scope.`);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="bg-white dark:bg-neutral-dark rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        <div className="p-4 border-b dark:border-gray-700 flex justify-between items-center">
          <h3 className="text-xl font-semibold text-primary-dark dark:text-primary-light">Thumbnail Editor (Simplified)</h3>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600">
            <CloseIcon className="h-6 w-6 text-neutral-dark dark:text-neutral-light" />
          </button>
        </div>

        <div className="flex-grow flex flex-col md:flex-row overflow-y-auto">
          {/* Preview Area */}
          <div className="md:w-2/3 p-4 flex items-center justify-center bg-gray-100 dark:bg-gray-800 relative">
            <div className="relative aspect-video max-w-full max-h-full">
              <img 
                src={imageUrl} 
                alt="Editable thumbnail" 
                className={`w-full h-full object-contain ${currentFilterCss}`}
              />
              {/* Text Overlay Preview (Simplified) */}
              {localText && (
                <div 
                  className="absolute pointer-events-none p-2"
                  style={{ 
                    fontFamily: localFont, 
                    color: localColor, 
                    fontSize: `${localSize}px`,
                    top: `${textOverlayOptions.position.y}%`, // Y position as percentage from top
                    left: `${textOverlayOptions.position.x}%`, // X position as percentage from left
                    transform: 'translate(-50%, -50%)', // Center the text if position marks center
                    // For more robust text on image, consider text shadow or outline
                    textShadow: '1px 1px 2px rgba(0,0,0,0.7)'
                  }}
                >
                  {localText}
                </div>
              )}
            </div>
          </div>

          {/* Editing Controls */}
          <div className="md:w-1/3 p-4 space-y-6 overflow-y-auto bg-white dark:bg-neutral-dark border-l dark:border-gray-700">
            {/* Text Overlay Controls */}
            <div className="space-y-3 p-3 border dark:border-gray-600 rounded-lg">
              <h4 className="font-medium text-neutral-dark dark:text-neutral-light">Text Overlay</h4>
              <input 
                type="text" 
                value={localText} 
                onChange={(e) => setLocalText(e.target.value)} 
                placeholder="Enter text"
                className="w-full p-2 border dark:border-gray-600 rounded bg-transparent dark:text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <select value={localFont} onChange={(e) => setLocalFont(e.target.value)} className="w-full p-2 border dark:border-gray-600 rounded bg-transparent dark:text-white dark:[color-scheme:dark]">
                  {TEXT_FONTS.map(font => <option key={font} value={font}>{font}</option>)}
                </select>
                <input type="color" value={localColor} onChange={(e) => setLocalColor(e.target.value)} className="w-full h-10 border dark:border-gray-600 rounded bg-transparent" />
              </div>
              <div className="flex items-center gap-2">
                 <label htmlFor="fontSize" className="text-sm dark:text-gray-300">Size:</label>
                 <input type="range" id="fontSize" min="10" max="72" value={localSize} onChange={(e) => setLocalSize(parseInt(e.target.value))} className="w-full accent-primary"/>
                 <span className="text-sm dark:text-gray-300 w-8 text-right">{localSize}px</span>
              </div>
              <button onClick={handleApplyText} className="w-full bg-accent hover:bg-accent-dark text-white py-2 rounded">Apply Text</button>
            </div>

            {/* Filter Controls */}
            <div className="space-y-3 p-3 border dark:border-gray-600 rounded-lg">
              <h4 className="font-medium text-neutral-dark dark:text-neutral-light">Filters</h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {EDITOR_FILTERS.map(filter => (
                  <button 
                    key={filter.id} 
                    onClick={() => onApplyFilter(filter.id, filter.cssClass)}
                    className={`p-2 border dark:border-gray-500 rounded text-sm hover:bg-primary/20 dark:hover:bg-primary-dark/30 ${currentFilterCss === filter.cssClass ? 'bg-primary/30 dark:bg-primary-dark/40 ring-2 ring-primary' : 'bg-gray-100 dark:bg-gray-700'}`}
                  >
                    {filter.name}
                  </button>
                ))}
                 <button 
                    onClick={() => onApplyFilter('none', '')} // Reset filter
                    className={`p-2 border dark:border-gray-500 rounded text-sm hover:bg-primary/20 dark:hover:bg-primary-dark/30 ${currentFilterCss === '' ? 'bg-primary/30 dark:bg-primary-dark/40 ring-2 ring-primary' : 'bg-gray-100 dark:bg-gray-700'}`}
                  >
                    None
                  </button>
              </div>
            </div>
            
            {/* Mock Tools */}
            <div className="space-y-3 p-3 border dark:border-gray-600 rounded-lg">
              <h4 className="font-medium text-neutral-dark dark:text-neutral-light">Other Tools (Mock)</h4>
              <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handleMockAction('Crop', 'transform_crop')} className="flex items-center justify-center gap-1 p-2 border dark:border-gray-500 rounded text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">
                  <CropIcon className="h-4 w-4"/> Crop
                </button>
                <button onClick={() => handleMockAction('Resize', 'transform_resize')} className="flex items-center justify-center gap-1 p-2 border dark:border-gray-500 rounded text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">
                  <ResizeIcon className="h-4 w-4"/> Resize
                </button>
                 <button onClick={() => handleMockAction('Background Remover', 'ai_smart_bg_remove')} className="col-span-2 p-2 border dark:border-gray-500 rounded text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600">
                  BG Remover
                </button>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400">More tools like stickers, shapes, etc., would be here.</p>
            </div>

            <button onClick={onClose} className="w-full bg-primary hover:bg-primary-dark text-white py-2.5 rounded-lg font-semibold">Done Editing</button>
          </div>
        </div>
      </div>
    </div>
  );
};