
import React from 'react';
import { APP_NAME, AVAILABLE_LANGUAGES } from '../constants';
import { Language } from '../types';

interface HeaderProps {
  darkMode: boolean;
  toggleDarkMode: () => void;
  onShowFeedback: () => void;
}

// A simple SVG icon for YT Genie
const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.455 19L2 22.5V4C2 3.44772 2.44772 3 3 3H21C21.5523 3 22 3.44772 22 4V18C22 18.5523 21.5523 19 21 19H6.455ZM12.4142 13.5858L16.9497 9.05025L15.5355 7.63604L11 12.1716L9.05025 10.2218L7.63604 11.636L11.1213 15H12.4142V13.5858Z" />
  </svg>
);

const SunIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
);

const MoonIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
  </svg>
);

const LanguageIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5h12M9 3v2m4 13l4-4M19 9l-4 4M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const MenuIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
    </svg>
);


export const Header: React.FC<HeaderProps> = ({ darkMode, toggleDarkMode, onShowFeedback }) => {
  const [currentLang, setCurrentLang] = React.useState<string>(AVAILABLE_LANGUAGES[0].code);
  const [showLangDropdown, setShowLangDropdown] = React.useState<boolean>(false);
  const [showMobileMenu, setShowMobileMenu] = React.useState<boolean>(false);

  const handleLinkClick = (action?: () => void, href?: string) => {
    setShowMobileMenu(false); // Close mobile menu on link click
    if (action) {
      action();
    } else if (href && href.startsWith('#')) {
        const elementId = href.substring(1);
        const element = document.getElementById(elementId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        } else if (href === '#') { // For # home link
            window.scrollTo({ top: 0, behavior: 'smooth'});
        }
    }
  };

  const navLinks = [
    { name: 'Home', href: '#', action: () => handleLinkClick(undefined, '#') },
    { name: 'AI Image Gen', href: '#ai-image-studio-section', action: () => handleLinkClick(undefined, '#ai-image-studio-section') },
    { name: 'SEO Tools', href: '#seo-tools-section', action: () => handleLinkClick(undefined, '#seo-tools-section') },
    { name: 'Guides', href: '#guides', action: () => { handleLinkClick(); alert('Guides section coming soon!');} },
    { name: 'Contact Us', href: '#contact', action: () => { handleLinkClick(onShowFeedback); } },
  ];
  
  const commonLinkClasses = "px-3 py-2 rounded-md text-sm font-medium text-neutral-dark dark:text-neutral-light hover:bg-primary/10 dark:hover:bg-primary-dark/20 hover:text-primary dark:hover:text-primary-light transition-colors";
  const mobileLinkClasses = "block " + commonLinkClasses;

  return (
    <header className="sticky top-0 z-50 bg-white/80 dark:bg-neutral-dark/80 backdrop-blur-lg shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-3">
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleLinkClick(undefined, '#')}>
                <LogoIcon className="h-8 w-8 text-primary dark:text-primary-light" />
                <h1 className="text-2xl font-bold text-primary dark:text-primary-light">{APP_NAME}</h1>
            </div>

            {/* Desktop Menu */}
            <nav className="hidden md:flex items-center space-x-1">
                {navLinks.map(link => (
                    <a key={link.name} href={link.href} onClick={(e) => { e.preventDefault(); link.action(); }} className={commonLinkClasses}>
                    {link.name}
                    </a>
                ))}
            </nav>

            <div className="flex items-center space-x-2">
                {/* Language Switcher - remains same */}
                <div className="relative hidden sm:block">
                    <button 
                    onClick={() => setShowLangDropdown(!showLangDropdown)}
                    className="p-2 rounded-full hover:bg-neutral-light/50 dark:hover:bg-neutral-dark/50 transition-colors"
                    aria-label="Change language"
                    >
                    <LanguageIcon className="h-6 w-6 text-neutral-dark dark:text-neutral-light" />
                    </button>
                    {showLangDropdown && (
                    <div className="absolute right-0 mt-2 w-36 bg-white dark:bg-gray-700 rounded-md shadow-lg py-1 z-20">
                        {AVAILABLE_LANGUAGES.map((lang: Language) => (
                        <button
                            key={lang.code}
                            onClick={() => {setCurrentLang(lang.code); setShowLangDropdown(false); alert(`Language changed to ${lang.name} (UI mock).`)}}
                            className={`block w-full text-left px-4 py-2 text-sm ${
                            currentLang === lang.code 
                                ? 'bg-primary/20 text-primary dark:text-primary-light' 
                                : 'text-gray-700 dark:text-gray-200'
                            } hover:bg-primary/10 dark:hover:bg-primary-dark/30`}
                        >
                            {lang.name}
                        </button>
                        ))}
                    </div>
                    )}
                </div>
                
                <button 
                    onClick={toggleDarkMode} 
                    className="p-2 rounded-full hover:bg-neutral-light/50 dark:hover:bg-neutral-dark/50 transition-colors"
                    aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
                >
                    {darkMode ? <SunIcon className="h-6 w-6 text-yellow-400" /> : <MoonIcon className="h-6 w-6 text-indigo-500" />}
                </button>

                {/* Mobile Menu Button */}
                <div className="md:hidden">
                    <button 
                        onClick={() => setShowMobileMenu(!showMobileMenu)}
                        className="p-2 rounded-full hover:bg-neutral-light/50 dark:hover:bg-neutral-dark/50 transition-colors"
                        aria-label="Open navigation menu"
                        aria-expanded={showMobileMenu}
                    >
                        <MenuIcon className="h-6 w-6 text-neutral-dark dark:text-neutral-light" />
                    </button>
                </div>
            </div>
        </div>
        
        {/* Mobile Menu */}
        {showMobileMenu && (
            <div className="md:hidden py-2 border-t border-gray-200 dark:border-gray-700">
                <nav className="flex flex-col space-y-1">
                    {navLinks.map(link => (
                    <a key={`mobile-${link.name}`} href={link.href} onClick={(e) => { e.preventDefault(); link.action(); }} className={mobileLinkClasses}>
                        {link.name}
                    </a>
                    ))}
                     {/* Mobile language switcher and feedback */}
                    <div className="pt-2 mt-2 border-t border-gray-200 dark:border-gray-700 space-y-1">
                        <button 
                            onClick={() => { onShowFeedback(); setShowMobileMenu(false);}}
                            className={mobileLinkClasses + " sm:hidden"} // Show feedback if hidden on desktop by class
                        >
                            Feedback
                        </button>
                        {AVAILABLE_LANGUAGES.map((lang: Language) => (
                            <button
                                key={`mobile-lang-${lang.code}`}
                                onClick={() => {setCurrentLang(lang.code); setShowLangDropdown(false); alert(`Language changed to ${lang.name} (UI mock).`); setShowMobileMenu(false);}}
                                className={`${mobileLinkClasses} ${ currentLang === lang.code ? 'bg-primary/20 text-primary dark:text-primary-light' : ''}`}
                            >
                                {lang.name}
                            </button>
                        ))}
                    </div>
                </nav>
            </div>
        )}
      </div>
    </header>
  );
};
