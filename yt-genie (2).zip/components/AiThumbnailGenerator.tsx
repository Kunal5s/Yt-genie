
import React from 'react';
import { AspectRatio } from '../types';
import { AVAILABLE_ASPECT_RATIOS } from '../constants';

interface AiImageGeneratorControlsProps {
  prompt: string;
  onPromptChange: (prompt: string) => void;
  aspectRatio: AspectRatio;
  onAspectRatioChange: (aspectRatio: AspectRatio) => void;
  onGenerate: (prompt: string, aspectRatio: AspectRatio) => void;
  isLoading: boolean;
}

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 3v4M3 5h4M19 3v4M17 5h4M12 3v10M9 13a3 3 0 013-3h0a3 3 0 013 3v2a3 3 0 01-3 3h0a3 3 0 01-3-3v-2zM5 21v-4M3 19h4M19 21v-4M17 19h4" />
  </svg>
);

export const AiImageGeneratorControls: React.FC<AiImageGeneratorControlsProps> = ({
  prompt,
  onPromptChange,
  aspectRatio,
  onAspectRatioChange,
  onGenerate,
  isLoading,
}) => {
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(prompt, aspectRatio);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="aiPrompt" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">
          Image Prompt
        </label>
        <textarea
          id="aiPrompt"
          rows={3}
          value={prompt}
          onChange={(e) => onPromptChange(e.target.value)}
          placeholder="e.g., A futuristic robot holding a glowing YouTube play button, cinematic lighting"
          className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-neutral-light/50 dark:bg-gray-700/80 text-neutral-dark dark:text-neutral-light focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light shadow-sm"
          required
        />
      </div>

      <div>
        <label htmlFor="aspectRatio" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">
          Aspect Ratio
        </label>
        <select
          id="aspectRatio"
          value={aspectRatio}
          onChange={(e) => onAspectRatioChange(e.target.value as AspectRatio)}
          className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-neutral-light/50 dark:bg-gray-700/80 text-neutral-dark dark:text-neutral-light focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light shadow-sm dark:[color-scheme:dark]"
        >
          {AVAILABLE_ASPECT_RATIOS.map(ar => (
            <option key={ar.value} value={ar.value}>{ar.label}</option>
          ))}
        </select>
      </div>
      
      <button
        type="submit"
        disabled={isLoading || !prompt.trim()}
        className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary-dark text-black font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed"
      >
        <SparklesIcon className="h-6 w-6" />
        {isLoading ? 'Generating Image...' : 'Generate Image with AI'}
      </button>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2 text-center">
        Uses AI (mocked Google Imagen) to create a unique image based on your prompt and selected aspect ratio.
      </p>
    </form>
  );
};