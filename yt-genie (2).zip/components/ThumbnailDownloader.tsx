import React from 'react';
import { VideoInfo, ThumbnailFormat } from '../types';

interface DownloadIconProps { // Explicitly define props for custom icon components
  className?: string;
}

const DownloadIconSvg: React.FC<DownloadIconProps> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);

export const ThumbnailDownloader: React.FC<ThumbnailDownloaderProps> = ({ videoInfo, currentThumbnailUrl }) => {
  
  const handleDownload = (format: ThumbnailFormat) => {
    const titleForFile = videoInfo?.title || 'yt_genie_image';
    const fileName = `${titleForFile.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_thumbnail.${format}`;
    
    const link = document.createElement('a');
    link.href = currentThumbnailUrl; // This URL could be a ytimg URL or a data URL (base64)
    
    // For data URLs, the browser can often infer the type. 
    // For remote URLs, the server provides the type.
    // If specific format conversion from JPEG (typical for YT) to PNG is needed from a URL,
    // it would require canvas manipulation or a server-side service.
    // This mock assumes currentThumbnailUrl is either already in the desired format (if data URL)
    // or that the format parameter is for naming convention here.
    
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert(`Download initiated for: ${fileName} (Format: ${format.toUpperCase()}). This uses the currently displayed image.`);
  };

  return (
    <div className="p-4 bg-neutral-light/30 dark:bg-gray-700/30 rounded-lg shadow">
      <h3 className="text-lg font-semibold text-neutral-dark dark:text-neutral-light mb-3">Download Displayed Thumbnail</h3>
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => handleDownload(ThumbnailFormat.JPEG)}
          className="flex-1 inline-flex items-center justify-center gap-2 bg-accent hover:bg-accent-dark text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
        >
          <DownloadIconSvg className="h-5 w-5" /> JPEG
        </button>
        <button
          onClick={() => handleDownload(ThumbnailFormat.PNG)}
          className="flex-1 inline-flex items-center justify-center gap-2 bg-secondary hover:bg-secondary-dark text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
        >
          <DownloadIconSvg className="h-5 w-5" /> PNG
        </button>
      </div>
      <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">Downloads the image currently shown in the main preview. For different original YouTube resolutions, specific URLs would typically be targeted.</p>
    </div>
  );
};

interface ThumbnailDownloaderProps { // Ensure props interface is defined or imported
  videoInfo: VideoInfo | null; // Allow null if a video might not be loaded (e.g. only AI image)
  currentThumbnailUrl: string;
}