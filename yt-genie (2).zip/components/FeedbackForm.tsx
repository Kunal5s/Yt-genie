
import React, { useState } from 'react';

interface FeedbackFormProps {
  onClose: () => void;
}

const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

export const FeedbackForm: React.FC<FeedbackFormProps> = ({ onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock submission
    console.log('Feedback submitted:', { name, email, message });
    setSubmitted(true);
    // In a real app, send this data to a backend API
    setTimeout(() => {
        onClose();
        setSubmitted(false); // Reset for next time
    }, 2000); 
  };

  if (submitted) {
    return (
      <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
        <div className="bg-white dark:bg-neutral-dark p-8 rounded-xl shadow-2xl text-center">
          <h3 className="text-2xl font-semibold text-accent mb-4">Thank You!</h3>
          <p className="text-neutral-dark dark:text-neutral-light">Your feedback has been received (mock).</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fade-in">
      <div className="bg-white dark:bg-neutral-dark p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-md relative">
        <button onClick={onClose} className="absolute top-3 right-3 p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600">
          <CloseIcon className="h-6 w-6 text-neutral-dark dark:text-neutral-light" />
        </button>
        <h3 className="text-2xl font-semibold text-primary-dark dark:text-primary-light mb-6 text-center">Share Your Feedback</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">Name (Optional)</label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-transparent dark:text-white focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">Email (Optional)</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-transparent dark:text-white focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light"
            />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">Message</label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              required
              className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-transparent dark:text-white focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light"
            ></textarea>
          </div>
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-primary to-secondary hover:from-primary-dark hover:to-secondary-dark text-black font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
          >
            Submit Feedback
          </button>
        </form>
      </div>
    </div>
  );
};