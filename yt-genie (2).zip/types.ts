export interface VideoInfo {
  id: string;
  title: string;
  thumbnailUrl: string;
  channelTitle: string;
  duration: string; // e.g. "PT5M30S" or "5:30"
}

export enum ThumbnailFormat {
  JPEG = 'jpeg',
  PNG = 'png',
}

export enum AudioFormat {
  MP3 = 'mp3',
}

export interface GeneratedContent {
  title: string;
  description: string;
  tags: string[];
  keywords: string[];
  viralHooks?: string[]; // Optional for now, to avoid breaking existing mock if not provided
  contentIdeas?: string[]; // Optional
}

export interface TextOverlayOptions {
  text: string;
  font: string;
  color: string;
  size: number; // font size
  position: { x: number; y: number }; // relative position
}

export interface FilterOption {
  id: string;
  name: string;
  cssClass: string; // Tailwind class for filter e.g. 'grayscale', 'sepia'
}

export interface Language {
  code: string;
  name: string;
}

export enum AspectRatio {
  SQUARE = '1:1', 
  WIDESCREEN = '16:9', 
  PORTRAIT = '9:16', 
  LANDSCAPE_4_3 = '4:3', 
  LANDSCAPE_3_2 = '3:2',
}

export interface ImageGenerationOptions {
  prompt: string;
  aspectRatio: AspectRatio;
  negativePrompt?: string;
  seed?: number;
  numberOfImages?: number; // Added for clarity, though hardcoded to 4 for now
}

export interface GeneratedImageDetail {
  id: string; // A unique ID for the image (e.g., derived from index or a hash)
  url: string; // The data URL or remote URL of the image
}

// Types for expanded editor tools
interface BaseTool {
  id: string;
  name: string;
  icon?: React.ReactNode;
  actionType: string; // To help mock service identify the tool type
}

export interface AdjustmentTool extends BaseTool {
  // e.g., for tools like brightness, contrast, exposure
  // It might have a 'value' and 'range' in a real app
}

export interface EffectTool extends BaseTool {
  // e.g., blur, sharpen, pixelate
}

export interface TransformTool extends BaseTool {
  // e.g., rotate, flip
}

export interface DecorationTool extends BaseTool {
  // e.g., stickers, frames
}

export interface AiSmartTool extends BaseTool {
  // e.g., AI upscale, object removal
}

// Deprecated, use more specific tool types above if needed, or keep generic for mocks
export interface EditTool {
  id: string;
  name: string;
  icon?: React.ReactNode; 
  action?: (currentImage: string) => Promise<string>; 
}