import { FilterOption, Language, AspectRatio, AdjustmentTool, EffectTool, TransformTool, DecorationTool, AiSmartTool, CustomizationOption, AiCustomizationCategory } from './types';    
import React from 'react'; 

// Simple placeholder icons
const PlaceholderIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🖼️');
const BrightnessIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '☀️');
const ContrastIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '◑');
const SaturationIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🎨');
const TemperatureIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🌡️');
const EffectsIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '✨');
const TransformIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🔄');
const TextIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, ' Tt ');
const StickerIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '😊');
const FrameIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🖼️');
const MagicWandIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🪄');

// Icons for customization options (using text/emoji as placeholders)
const StyleIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🎨'); // Generic style
const MoodIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🎭'); // Generic mood
const LightingIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '💡'); // Generic lighting
const ColorIcon: React.FC<{className?: string}> = ({className}) => React.createElement('span', { className }, '🌈'); // Generic color


export const APP_NAME = "YT Genie";
export const NUMBER_OF_IMAGES_TO_GENERATE = 4;
export const LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY = 'ytGenieCustomizationFilters';

export const MOCK_VIDEO_URL_PREFIX = "https://www.youtube.com/watch?v=";
export const MOCK_THUMBNAIL_BASE_URL = "https://i.ytimg.com/vi/"; 
export const PLACEHOLDER_IMAGE_URL = "https://picsum.photos/seed/ytgenieplaceholder/480/360"; 

export const AVAILABLE_LANGUAGES: Language[] = [
  { code: 'en', name: 'English' },
  { code: 'es', name: 'Español' },
  { code: 'fr', name: 'Français' },
];

export const AVAILABLE_ASPECT_RATIOS: { label: string, value: AspectRatio }[] = [
  { label: 'Widescreen (16:9)', value: AspectRatio.WIDESCREEN },
  { label: 'Square (1:1)', value: AspectRatio.SQUARE },
  { label: 'Portrait (9:16)', value: AspectRatio.PORTRAIT },
  { label: 'Landscape (4:3)', value: AspectRatio.LANDSCAPE_4_3 },
  { label: 'Landscape (3:2)', value: AspectRatio.LANDSCAPE_3_2 },
];

export const EDITOR_FILTERS: FilterOption[] = [
  { id: 'grayscale', name: 'Grayscale', cssClass: 'grayscale' },
  { id: 'sepia', name: 'Sepia', cssClass: 'sepia' },
  // ... other filters
];

export const TEXT_FONTS = ['Arial', 'Verdana', 'Times New Roman', 'Courier New', 'Georgia', 'Comic Sans MS', 'Impact', 'Roboto', 'Montserrat'];

// Mock Editor Tools Definitions
export const MOCK_ADJUSTMENT_TOOLS: AdjustmentTool[] = [
  { id: 'brightness', name: 'Brightness', icon: React.createElement(BrightnessIcon, { className: "h-4 w-4"}), actionType: 'adjustment_brightness' },
  // ... other adjustment tools
];
export const MOCK_EFFECT_TOOLS: EffectTool[] = [ /* ... */ ];
export const MOCK_TRANSFORM_TOOLS: TransformTool[] = [ /* ... */ ];
export const MOCK_DECORATION_TOOLS: DecorationTool[] = [ /* ... */ ];
export const MOCK_AI_SMART_TOOLS: AiSmartTool[] = [ /* ... */ ];


// AI Image Customization Options
const createOption = (name: string, tooltip?: string, icon?: string | React.ReactNode): CustomizationOption => ({
  id: name.toLowerCase().replace(/\s+/g, '-'),
  name,
  icon: icon || name.charAt(0).toUpperCase(), // Default icon is first letter
  tooltip: tooltip || name,
});

export const AI_IMAGE_STYLES: CustomizationOption[] = [
  createOption('3D', 'Render in a 3D style', '🧊'),
  createOption('8-bit', 'Pixelated 8-bit retro style', '👾'),
  createOption('Analogue', 'Vintage analogue film look', '🎞️'),
  createOption('Anime', 'Japanese animation style', '🌸'),
  createOption('Cartoon', 'Classic cartoon illustration', '✏️'),
  createOption('Collage', 'Mixed media collage effect', '🧩'),
  createOption('Cookie', 'Looks like it\'s made of cookie', '🍪'),
  createOption('Crayon', 'Drawn with crayons', '🖍️'),
  createOption('Doodle', 'Hand-drawn doodle sketch', '✍️'),
  createOption('Dough', 'Made of dough or clay', '🍞'),
  createOption('Felt', 'Crafted from felt material', '🧵'),
  createOption('Illustrated', 'Detailed illustration style', '📖'),
  createOption('Marker', 'Drawn with markers', '✒️'),
  createOption('Mechanical', 'Steampunk or mechanical parts', '⚙️'),
  createOption('Painting', 'Classic painting aesthetic', '🖼️'),
  createOption('Paper', 'Papercraft or origami style', '📜'),
  createOption('Pin', 'Enamel pin design', '📍'),
  createOption('Plushie', 'Soft plush toy look', '🧸'),
  createOption('Realistic', 'Photorealistic rendering', '📷'),
  createOption('Tattoo', 'Tattoo art style', '🐉'),
  createOption('Woodblock', 'Japanese woodblock print style', '🌊'),
];

export const AI_IMAGE_MOODS: CustomizationOption[] = [
  createOption('Sweets', 'Candy and dessert themed', '🍬'),
  createOption('Classical', 'Elegant and timeless', '🏛️'),
  createOption('Cyberpunk', 'Futuristic neon and tech', '🌃'),
  createOption('Dreamy', 'Soft, ethereal, and surreal', '💭'),
  createOption('Glowy', 'Luminous and radiant', '✨'),
  createOption('Gothic', 'Dark, mysterious, and ornate', '🦇'),
  createOption('Kawaii', 'Cute and adorable Japanese style', '💖'),
  createOption('Mystical', 'Magical and enchanted', '🔮'),
  createOption('Trippy', 'Psychedelic and mind-bending', '🌀'),
  createOption('Tropical', 'Lush, vibrant, and exotic', '🌴'),
  createOption('Steampunk', 'Victorian futurism with steam power', '🕰️'),
  createOption('Wasteland', 'Post-apocalyptic and desolate', '🏜️'),
];

export const AI_IMAGE_LIGHTING: CustomizationOption[] = [
  createOption('Bright', 'Well-lit and vibrant', '☀️'),
  createOption('Dark', 'Shadowy and low-light', '🌙'),
  createOption('Neon', 'Glowing neon lights effect', '🚦'),
  createOption('Sunset', 'Warm golden hour lighting', '🌅'),
  createOption('Misty', 'Foggy and atmospheric', '🌫️'),
  createOption('Ethereal', 'Soft, glowing, otherworldly light', '😇'),
];

export const AI_IMAGE_COLORS: CustomizationOption[] = [
  createOption('Cool', 'Blues, greens, and purples', '❄️'),
  createOption('Earthy', 'Browns, greens, and natural tones', '🍂'),
  createOption('Indigo', 'Deep blues and purples', '🌌'),
  createOption('Infrared', 'Simulated infrared photography', '♨️'),
  createOption('Pastel', 'Soft, muted, and gentle colors', '🌸'),
  createOption('Warm', 'Reds, oranges, and yellows', '🔥'),
];

export const AI_CUSTOMIZATION_CATEGORIES: AiCustomizationCategory[] = [
  { id: 'style', name: 'Styles', options: AI_IMAGE_STYLES },
  { id: 'mood', name: 'Moods', options: AI_IMAGE_MOODS },
  { id: 'lighting', name: 'Lighting', options: AI_IMAGE_LIGHTING },
  { id: 'color', name: 'Colors', options: AI_IMAGE_COLORS },
];
