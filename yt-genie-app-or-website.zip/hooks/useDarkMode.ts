
import { useState, useEffect } from 'react';

// This hook is no longer actively used as the dark mode is now default and non-toggleable.
// Keeping the file for now in case of future changes, but the App component no longer calls it.
export const useDarkMode = (): [boolean, () => void] => {
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    // if (typeof window !== 'undefined') {
    //   const storedPreference = localStorage.getItem('darkMode');
    //   if (storedPreference !== null) {
    //     return JSON.parse(storedPreference);
    //   }
    //   // Default to dark mode if no preference, or if matchMedia is not supported
    //   return window.matchMedia?.('(prefers-color-scheme: dark)')?.matches ?? true;
    // }
    return true; // Default to true (dark mode)
  });

  useEffect(() => {
    // if (typeof window !== 'undefined') {
    //   const root = window.document.documentElement;
    //   if (darkMode) {
    //     root.classList.add('dark'); // This class is now handled by Tailwind config if needed, or body class
    //   } else {
    //     root.classList.remove('dark');
    //   }
    //   localStorage.setItem('darkMode', JSON.stringify(darkMode));
    // }
  }, [darkMode]);

  const toggleDarkMode = () => {
    // setDarkMode(prevMode => !prevMode); // Toggle functionality removed
  };

  return [darkMode, toggleDarkMode];
};