
import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SearchBar } from './components/SearchBar';
import { VideoPreview } from './components/VideoPreview';
import { ThumbnailDownloader } from './components/ThumbnailDownloader';
import { AudioDownloader } from './components/AudioDownloader';
import { AiImageGeneratorControls } from './components/AiThumbnailGenerator';
import { ThumbnailEditor } from './components/ThumbnailEditor';
import { SeoContentGenerator } from './components/SeoContentGenerator';
import { TrendingThumbnails } from './components/TrendingThumbnails';
import { FeedbackForm } from './components/FeedbackForm';
import { SocialShare } from './components/SocialShare';
// import { useDarkMode } from './hooks/useDarkMode'; // Dark mode toggle removed
import { VideoInfo, GeneratedContent, TextOverlayOptions, AspectRatio, GeneratedImageDetail, AiCustomizationFilters, AiCustomizationFilterCategory } from './types';
import { fetchVideoInfo as mockFetchVideoInfo } from './services/youtubeService';
import { 
  generateImageFromText,
  generateSeoContent,
  applyMockEdit 
} from './services/geminiService';
import { PLACEHOLDER_IMAGE_URL, AVAILABLE_ASPECT_RATIOS, APP_NAME, NUMBER_OF_IMAGES_TO_GENERATE, LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY, AI_CUSTOMIZATION_CATEGORIES } from './constants';

// Page Components
import { AboutUsPage } from './components/pages/AboutUsPage';
import { ContactUsPage } from './components/pages/ContactUsPage';
import { PrivacyPolicyPage } from './components/pages/PrivacyPolicyPage';
import { TermsOfServicePage } from './components/pages/TermsOfServicePage';
import { DisclaimerPage } from './components/pages/DisclaimerPage';


// Icons for generated image actions
const DownloadIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);
const EditIcon: React.FC<{ className?: string }> = ({ className }) => (
 <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
  </svg>
);

const initialCustomizationFilters: AiCustomizationFilters = {
  style: '',
  mood: '',
  lighting: '',
  color: '',
};

export type PageName = 'home' | 'about' | 'contact' | 'privacy' | 'terms' | 'disclaimer';


const App: React.FC = () => {
  // const [darkMode, toggleDarkMode] = useDarkMode(); // Dark mode state and toggle removed
  const [youtubeUrl, setYoutubeUrl] = useState<string>('');
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null);
  const [currentThumbnail, setCurrentThumbnail] = useState<string>(PLACEHOLDER_IMAGE_URL);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>('Processing...');
  const [error, setError] = useState<string | null>(null);
  const [seoContent, setSeoContent] = useState<GeneratedContent | null>(null);
  const [showEditor, setShowEditor] = useState<boolean>(false);
  const [showFeedbackForm, setShowFeedbackForm] = useState<boolean>(false);
  
  const [imagePrompt, setImagePrompt] = useState<string>('');
  const [userSeoPrompt, setUserSeoPrompt] = useState<string>('');
  const [selectedAspectRatio, setSelectedAspectRatio] = useState<AspectRatio>(AVAILABLE_ASPECT_RATIOS[0].value);
  const [generatedImages, setGeneratedImages] = useState<GeneratedImageDetail[]>([]);
  const [customizationFilters, setCustomizationFilters] = useState<AiCustomizationFilters>(initialCustomizationFilters);


  const [textOverlay, setTextOverlay] = useState<TextOverlayOptions>({ text: 'Your Text Here', font: 'Arial', color: '#FFFFFF', size: 24, position: { x: 10, y: 90 } });
  const [activeFilter, setActiveFilter] = useState<string>('');

  const [currentPage, setCurrentPage] = useState<PageName>('home');
  const [targetSection, setTargetSection] = useState<string | null>(null);

  const navigateTo = useCallback((page: PageName, sectionId?: string) => {
    setCurrentPage(page);
    setTargetSection(sectionId || null);
     if (!sectionId && page === 'home') { 
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (page !== 'home') { 
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    if (currentPage === 'home' && targetSection) {
      const element = document.getElementById(targetSection);
      if (element) {
        setTimeout(() => {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
            setTargetSection(null); 
        }, 50); 
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setTargetSection(null);
      }
    }
  }, [currentPage, targetSection]);


  useEffect(() => {
    const storedFilters = localStorage.getItem(LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY);
    if (storedFilters) {
      try {
        const parsedFilters = JSON.parse(storedFilters) as AiCustomizationFilters;
        const validFilters = { ...initialCustomizationFilters };
        let filtersChanged = false;
        (Object.keys(parsedFilters) as Array<keyof AiCustomizationFilters>).forEach(key => {
            if (parsedFilters[key] !== undefined && initialCustomizationFilters.hasOwnProperty(key)) {
                 const category = AI_CUSTOMIZATION_CATEGORIES.find(c => c.id === key);
                 if (category && (parsedFilters[key] === '' || category.options.some(opt => opt.id === parsedFilters[key]))) {
                    validFilters[key] = parsedFilters[key];
                 } else if (parsedFilters[key] !== '') {
                     filtersChanged = true; 
                 }
            } else {
                filtersChanged = true; 
            }
        });
        setCustomizationFilters(validFilters);
        if(filtersChanged) { 
            localStorage.setItem(LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY, JSON.stringify(validFilters));
        }

      } catch (e) {
        console.error("Failed to parse customization filters from local storage", e);
        localStorage.removeItem(LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY); 
      }
    }
  }, []);

  const handleCustomizationFilterChange = useCallback((category: AiCustomizationFilterCategory, value: string) => {
    setCustomizationFilters(prevFilters => {
      const newFilters = { ...prevFilters, [category]: value };
      localStorage.setItem(LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY, JSON.stringify(newFilters));
      return newFilters;
    });
  }, []);


  const resetToInitialState = () => {
    // ... (keep existing reset logic)
    setCustomizationFilters(initialCustomizationFilters);
    localStorage.removeItem(LOCAL_STORAGE_CUSTOMIZATION_FILTERS_KEY);
    navigateTo('home');
  };

  const handleSearch = useCallback(async (url: string) => {
    if (!url) {
      setError("Please enter a YouTube video URL.");
      setVideoInfo(null);
      setSeoContent(null); 
      return;
    }
    setIsLoading(true);
    setLoadingMessage('Fetching video information...');
    setError(null);
    setSeoContent(null); 
    setShowEditor(false);
    try {
      const info = await mockFetchVideoInfo(url);
      setVideoInfo(info);
      setCurrentThumbnail(info.thumbnailUrl); 
      setYoutubeUrl(url); 
      if (info.title && !imagePrompt) { 
        setImagePrompt(`Create a captivating YouTube thumbnail for a video titled: "${info.title}"`);
      }
      if (info.title && !userSeoPrompt) {
        setUserSeoPrompt(info.title);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch video info.");
      setVideoInfo(null);
      if (currentThumbnail.startsWith('https://i.ytimg.com/')) {
          setCurrentThumbnail(PLACEHOLDER_IMAGE_URL);
      }
    } finally {
      setIsLoading(false);
    }
  }, [imagePrompt, currentThumbnail, userSeoPrompt]);

  const handleImageError = useCallback((fallbackUrl: string) => {
    console.warn("Original thumbnail failed to load, switching to fallback:", fallbackUrl);
    setCurrentThumbnail(fallbackUrl);
  },[]);

  const handleGenerateImageFromText = useCallback(async (prompt: string, aspectRatio: AspectRatio, filters: AiCustomizationFilters) => {
    if (!prompt.trim()) {
      setError("Please enter a prompt for AI image generation.");
      return;
    }
    setIsLoading(true);
    setLoadingMessage(`Generating ${NUMBER_OF_IMAGES_TO_GENERATE} AI images...`);
    setError(null);
    setGeneratedImages([]); 
    try {
      const aiGeneratedImageDetails = await generateImageFromText(prompt, aspectRatio, filters); 
      setGeneratedImages(aiGeneratedImageDetails);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate AI images. Ensure API Key is valid and Imagen API is enabled.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleSelectGeneratedImageForEditing = (imageUrl: string) => {
    setCurrentThumbnail(imageUrl);
    setShowEditor(false); 
    if (!userSeoPrompt && imagePrompt){
        setUserSeoPrompt(imagePrompt);
    }
     const mainPreviewArea = document.getElementById('main-preview-area');
     if (mainPreviewArea && currentPage === 'home') {
        mainPreviewArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
     } else if (currentPage !== 'home') {
        navigateTo('home', 'main-preview-area');
     } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
     }
  };

  const downloadGeneratedImage = (imageUrl: string, prompt: string, index: number) => {
    const link = document.createElement('a');
    link.href = imageUrl;
    const safePrompt = prompt.substring(0, 30).replace(/[^a-z0-9]/gi, '_').toLowerCase() || 'ai_image';
    link.download = `${safePrompt}_${index + 1}.jpeg`; 
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleGenerateSeo = useCallback(async () => {
    const contextForSeo = userSeoPrompt.trim() || videoInfo?.title || imagePrompt.trim();

    if (!contextForSeo) {
       setError("Please provide a topic/idea, load a video, or generate an image to create context for SEO content.");
       return;
    }

    setIsLoading(true);
    setLoadingMessage('Generating SEO content with AI...');
    setError(null);
    setSeoContent(null);
    try {
      const content = await generateSeoContent(contextForSeo);
      setSeoContent(content);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to generate SEO content. Check API Key and Gemini API settings.");
    } finally {
      setIsLoading(false);
    }
  }, [videoInfo, imagePrompt, userSeoPrompt]);

  const handleEditThumbnail = () => {
    if (currentThumbnail !== PLACEHOLDER_IMAGE_URL) {
      setShowEditor(true);
    } else {
      setError("Please load or generate a thumbnail to edit.");
    }
  };

  const handleApplyTextOverlay = useCallback(async (options: TextOverlayOptions) => {
    setTextOverlay(options);
    await applyMockEdit(currentThumbnail, `text: ${options.text}, font: ${options.font}, color: ${options.color}, size: ${options.size}`);
    alert(`Text overlay "${options.text}" applied (mock).`);
  }, [currentThumbnail]);

  const handleApplyFilter = useCallback(async (filterId: string, filterCssClass: string) => {
    setActiveFilter(filterCssClass);
    await applyMockEdit(currentThumbnail, `filter: ${filterId}`);
    alert(`Filter "${filterId}" applied (mock).`);
  }, [currentThumbnail]);

  const handleApplyMockEditTool = useCallback(async (toolName: string, toolActionType: string) => {
    setIsLoading(true);
    setLoadingMessage(`Applying ${toolName}...`);
    try {
      await applyMockEdit(currentThumbnail, `tool: ${toolName}, action: ${toolActionType}`);
      alert(`Mock Tool: "${toolName}" applied.`);
    } catch(err) {
      setError(err instanceof Error ? err.message : `Failed to apply ${toolName}.`);
    } finally {
      setIsLoading(false);
    }
  }, [currentThumbnail]);
  
  const showWelcomeMessage = currentPage === 'home' && !videoInfo && !isLoading && generatedImages.length === 0 && currentThumbnail === PLACEHOLDER_IMAGE_URL && !error && !userSeoPrompt;


  return (
    <div className="min-h-screen flex flex-col bg-pf-bgDark text-pf-textLight">
      <Header 
        // darkMode={darkMode} // Removed
        // toggleDarkMode={toggleDarkMode} // Removed
        onShowFeedback={() => setShowFeedbackForm(true)} 
        onNavigate={navigateTo}
        currentPage={currentPage}
      />
      
      <main className="flex-grow container mx-auto px-4 py-8 space-y-8 sm:space-y-12">
        {isLoading && currentPage === 'home' && ( 
          <div className="flex flex-col justify-center items-center py-10">
            <div className={`animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-primary ${loadingMessage.includes("AI images") || loadingMessage.includes("SEO content") ? 'animate-pulse-fast' :''}`}></div>
            <p className="ml-4 mt-4 text-lg text-pf-textLight">{loadingMessage}</p>
          </div>
        )}
         {error && <p className="mt-4 text-red-400 text-center text-sm shadow-md rounded p-3 bg-red-700/30 border border-red-500/50">{error}</p>}


        {currentPage === 'home' && (
          <>
            {showWelcomeMessage && (
              <section id="welcome-yt-genie" className="text-center py-16 px-4 bg-gradient-to-br from-pf-bgMedium/50 to-pf-bgDark/80 rounded-xl shadow-2xl animate-fade-in border border-pf-borderLight">
                 <div className="inline-block px-4 py-1 mb-6 text-sm font-medium text-pf-accent bg-pf-accent/10 rounded-full border border-pf-accent/30">
                    Next-Generation AI Image Creation
                 </div>
                 <h1 className="text-4xl sm:text-6xl font-extrabold mb-6 text-pf-textLight leading-tight">
                  Create Stunning <span className="text-pf-accent">AI Images</span> in Seconds
                </h1>
                <p className="text-lg sm:text-xl text-pf-textMedium max-w-3xl mx-auto mb-10">
                  Experience the future of creative expression with our cutting-edge AI models, delivering photo-realistic, cinematic, and stylized results with precision and speed.
                </p>
                <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
                    <button 
                        onClick={() => { const el = document.getElementById('ai-image-studio-section'); if (el) el.scrollIntoView({behavior: 'smooth'}); }}
                        className="bg-primary hover:bg-primary-dark text-pf-textDark font-semibold py-3 px-8 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 text-lg"
                    >
                        Start Creating
                    </button>
                    <button 
                        onClick={() => { const el = document.getElementById('trending'); if (el) el.scrollIntoView({behavior: 'smooth'}); }}
                        className="bg-transparent hover:bg-pf-bgLight text-pf-accent font-semibold py-3 px-8 rounded-lg border-2 border-pf-accent hover:border-primary-dark shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 text-lg"
                    >
                        Explore Styles
                    </button>
                </div>
              </section>
            )}

            <section id="youtube-url-search" className="animate-fade-in">
              <SearchBar onSearch={handleSearch} isLoading={isLoading && loadingMessage.includes('Fetching video')} />
            </section>
            
            {(!isLoading && (videoInfo || (currentThumbnail !== PLACEHOLDER_IMAGE_URL && !videoInfo && generatedImages.length > 0 ))) && (
                <section id="main-preview-area" className="animate-slide-up bg-pf-bgMedium p-6 rounded-xl shadow-xl max-w-3xl mx-auto border border-pf-borderLight">
                    {videoInfo ? (
                        <VideoPreview 
                            videoInfo={videoInfo} 
                            currentThumbnail={currentThumbnail} 
                            onImageError={handleImageError} 
                        />
                    ) : (
                        <div className="text-center">
                            <h2 className="text-2xl font-semibold text-pf-accent mb-4">Selected Image Preview</h2>
                            <img 
                                src={currentThumbnail} 
                                alt="Selected AI image" 
                                className="w-full aspect-video object-contain rounded-lg shadow-md bg-pf-bgLight border border-pf-borderLight"
                                onError={(e) => { (e.target as HTMLImageElement).src = PLACEHOLDER_IMAGE_URL; }}
                            />
                        </div>
                    )}
                    <div className="mt-6 space-y-4">
                        {videoInfo && (
                            <>
                                <ThumbnailDownloader videoInfo={videoInfo} currentThumbnailUrl={currentThumbnail} />
                                <AudioDownloader videoInfo={videoInfo} />
                            </>
                        )}
                        {currentThumbnail !== PLACEHOLDER_IMAGE_URL && (
                            <button 
                                onClick={handleEditThumbnail}
                                disabled={isLoading}
                                className="w-full bg-primary hover:bg-primary-dark text-pf-textDark font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                            >
                                <EditIcon className="h-5 w-5"/> Edit This Image
                            </button>
                        )}
                    </div>
                </section>
            )}

            <section id="ai-image-studio-section" className={`py-6 animate-fade-in ${(isLoading && !loadingMessage.includes("AI images")) ? 'opacity-60 pointer-events-none' : ''}`}>
                <div className="max-w-3xl mx-auto bg-pf-bgMedium p-6 rounded-xl shadow-xl border border-pf-borderLight">
                    <h2 className="text-2xl sm:text-3xl font-bold text-pf-accent mb-6 text-center">
                        <span role="img" aria-label="sparkles" className="mr-2">✨</span> AI Image Generation Studio
                    </h2>
                    <AiImageGeneratorControls
                      prompt={imagePrompt}
                      onPromptChange={setImagePrompt}
                      aspectRatio={selectedAspectRatio}
                      onAspectRatioChange={setSelectedAspectRatio}
                      customizationFilters={customizationFilters}
                      onCustomizationFilterChange={handleCustomizationFilterChange}
                      onGenerate={handleGenerateImageFromText}
                      isLoading={isLoading && loadingMessage.includes("AI images")}
                    />
                </div>
            </section>
            
            {generatedImages.length > 0 && !isLoading && (
              <section id="ai-generated-gallery" className="animate-slide-up mt-2 mb-6">
                <h2 className="text-2xl font-bold text-center mb-6 text-pf-accent">
                  Your AI Generated Images ({generatedImages.length} variants)
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {generatedImages.map((img, index) => (
                    <div key={img.id} className="bg-pf-bgMedium rounded-xl shadow-xl overflow-hidden group p-3 border border-pf-borderLight">
                      <div className="aspect-video rounded-md overflow-hidden mb-3">
                        <img src={img.url} alt={`AI Generated Image ${index + 1}`} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
                      </div>
                      <div className="space-y-2">
                        <button
                          onClick={() => downloadGeneratedImage(img.url, imagePrompt, index)}
                          className="w-full flex items-center justify-center gap-2 text-sm bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-3 rounded-md transition-colors"
                          title="Download this image"
                        >
                          <DownloadIcon className="h-4 w-4"/> Download
                        </button>
                        <button
                          onClick={() => handleSelectGeneratedImageForEditing(img.url)}
                          className="w-full flex items-center justify-center gap-2 text-sm bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-3 rounded-md transition-colors"
                          title="Select this image for main preview and editing"
                        >
                         <EditIcon className="h-4 w-4"/> Preview & Edit
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                 <p className="text-center text-xs text-pf-textMedium mt-4">Click 'Preview & Edit' to make an image your main preview and enable editing for it.</p>
              </section>
            )}

            <section id="seo-tools-section" className={`py-6 animate-fade-in ${(isLoading && !loadingMessage.includes("SEO")) ? 'opacity-60 pointer-events-none' : ''}`}>
                <div className="max-w-3xl mx-auto bg-pf-bgMedium p-6 rounded-xl shadow-xl border border-pf-borderLight">
                    <SeoContentGenerator 
                        userPrompt={userSeoPrompt}
                        onUserPromptChange={setUserSeoPrompt}
                        onGenerate={handleGenerateSeo} 
                        generatedContent={seoContent} 
                        isLoading={isLoading && loadingMessage.includes("SEO")} 
                        contextPrompt={userSeoPrompt || videoInfo?.title || imagePrompt}
                    />
                </div>
            </section>

            {showEditor && (
              <section id="thumbnail-editor-modal" className="animate-slide-up">
                 <ThumbnailEditor
                  imageUrl={currentThumbnail}
                  onClose={() => setShowEditor(false)}
                  textOverlayOptions={textOverlay}
                  onTextOverlayChange={handleApplyTextOverlay}
                  currentFilterCss={activeFilter}
                  onApplyFilter={handleApplyFilter}
                  onApplyMockEditTool={handleApplyMockEditTool} 
                />
              </section>
            )}
            
            <TrendingThumbnails />
            <SocialShare videoUrl={youtubeUrl} videoTitle={videoInfo?.title} />
          </>
        )}
        
        {currentPage === 'about' && <AboutUsPage onNavigate={navigateTo} />}
        {currentPage === 'contact' && <ContactUsPage onNavigate={navigateTo} onShowFeedback={() => setShowFeedbackForm(true)} />}
        {currentPage === 'privacy' && <PrivacyPolicyPage onNavigate={navigateTo} />}
        {currentPage === 'terms' && <TermsOfServicePage onNavigate={navigateTo} />}
        {currentPage === 'disclaimer' && <DisclaimerPage onNavigate={navigateTo} />}

      </main>
      
      {showFeedbackForm && <FeedbackForm onClose={() => setShowFeedbackForm(false)} />}
      <Footer onNavigate={navigateTo} />
    </div>
  );
};

export default App;