export interface VideoInfo {
  id: string;
  title: string;
  thumbnailUrl: string;
  channelTitle: string;
  duration: string; // e.g., "PT5M30S" or "5:30"
}

export enum ThumbnailFormat {
  JPEG = 'jpeg',
  PNG = 'png',
}

export enum AudioFormat {
  MP3 = 'mp3',
}

export interface GeneratedContent {
  title: string;
  description: string;
  tags: string[];
  keywords: string[];
  viralHooks?: string[];
  contentIdeas?: string[];
}

export interface TextOverlayOptions {
  text: string;
  font: string;
  color: string;
  size: number; // font size
  position: { x: number; y: number }; // relative position
}

export interface FilterOption {
  id: string;
  name: string;
  cssClass: string; // Tailwind class for filter e.g. 'grayscale', 'sepia'
}

export interface Language {
  code: string;
  name: string;
}

export enum AspectRatio {
  SQUARE = '1:1', 
  WIDESCREEN = '16:9', 
  PORTRAIT = '9:16', 
  LANDSCAPE_4_3 = '4:3', 
  LANDSCAPE_3_2 = '3:2',
}

export interface ImageGenerationOptions {
  prompt: string;
  aspectRatio: AspectRatio;
  negativePrompt?: string;
  seed?: number;
  numberOfImages?: number;
  customizationFilters?: AiCustomizationFilters; // Added for new filters
}

export interface GeneratedImageDetail {
  id: string; 
  url: string; 
}

// Types for expanded editor tools
interface BaseTool {
  id: string;
  name: string;
  icon?: React.ReactNode;
  actionType: string; 
}

export interface AdjustmentTool extends BaseTool {}
export interface EffectTool extends BaseTool {}
export interface TransformTool extends BaseTool {}
export interface DecorationTool extends BaseTool {}
export interface AiSmartTool extends BaseTool {}

export interface EditTool {
  id: string;
  name: string;
  icon?: React.ReactNode; 
  action?: (currentImage: string) => Promise<string>; 
}

// New types for AI Image Customization
export interface CustomizationOption {
  id: string;
  name: string;
  icon?: string | React.ReactNode; // Placeholder for icon, could be emoji or SVG string/component
  tooltip: string;
}

export type AiCustomizationFilterCategory = 'style' | 'mood' | 'lighting' | 'color';

export interface AiCustomizationFilters {
  style: string;
  mood: string;
  lighting: string;
  color: string;
}

export interface AiCustomizationCategory {
  id: AiCustomizationFilterCategory;
  name: string;
  options: CustomizationOption[];
}