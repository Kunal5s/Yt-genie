
import { VideoInfo } from '../types';
import { MOCK_THUMBNAIL_BASE_URL, MOCK_VIDEO_URL_PREFIX } from '../constants';

// Helper to extract video ID (simplified)
const extractVideoId = (url: string): string | null => {
  try {
    const urlObj = new URL(url);
    if (urlObj.hostname === 'www.youtube.com' || urlObj.hostname === 'youtube.com') {
      return urlObj.searchParams.get('v');
    }
    if (urlObj.hostname === 'youtu.be') {
      return urlObj.pathname.substring(1);
    }
  } catch (e) {
    // Invalid URL
  }
  return null;
};


export const fetchVideoInfo = async (url: string): Promise<VideoInfo> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const videoId = extractVideoId(url);

      if (!videoId) {
        reject(new Error("Invalid YouTube URL. Please use a valid format (e.g., https://www.youtube.com/watch?v=VIDEO_ID or https://youtu.be/VIDEO_ID)."));
        return;
      }
      
      // Simulate API call
      if (videoId === 'dQw4w9WgXcQ') { // Rick Astley example
        resolve({
          id: videoId,
          title: 'Rick Astley - Never Gonna Give You Up (Official Music Video)',
          thumbnailUrl: `${MOCK_THUMBNAIL_BASE_URL}${videoId}/hqdefault.jpg`,
          channelTitle: 'Rick Astley',
          duration: 'PT3M32S', // ISO 8601 duration format
        });
      } else if (videoId === 'test12345') {
         resolve({
          id: videoId,
          title: 'Amazing Test Video - Highlights Reel',
          thumbnailUrl: `${MOCK_THUMBNAIL_BASE_URL}${videoId}/hqdefault.jpg`, 
          channelTitle: 'Test Channel',
          duration: 'PT10M5S',
        });
      } else {
         // Generic fallback for any other ID - Attempt to use standard YouTube thumbnail URL
         resolve({
          id: videoId,
          title: `Sample Video Title for ID: ${videoId}`,
          thumbnailUrl: `${MOCK_THUMBNAIL_BASE_URL}${videoId}/hqdefault.jpg`, 
          channelTitle: 'Sample Channel',
          duration: 'PT7M42S',
        });
      }
    }, 1000); // Simulate network delay
  });
};