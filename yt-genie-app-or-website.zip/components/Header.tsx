
import React from 'react';
import { APP_NAME, AVAILABLE_LANGUAGES } from '../constants';
import { Language } from '../types';
import { PageName } from '../App'; 

interface HeaderProps {
  // darkMode: boolean; // Removed
  // toggleDarkMode: () => void; // Removed
  onShowFeedback: () => void;
  onNavigate: (page: PageName, sectionId?: string) => void; 
  currentPage: PageName;
}

// A simple SVG icon for YT Genie
const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    {/* Using a simpler, more abstract logo similar to PixelForge concept */}
    <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2ZM8 13.5V10.5C8 9.67 8.67 9 9.5 9h5C15.33 9 16 9.67 16 10.5v3c0 .83-.67 1.5-1.5 1.5h-5C8.67 15 8 14.33 8 13.5Z" />
  </svg>
);

const LanguageIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5h12M9 3v2m4 13l4-4M19 9l-4 4M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const MenuIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
    </svg>
);


export const Header: React.FC<HeaderProps> = ({ onShowFeedback, onNavigate, currentPage }) => {
  const [currentLang, setCurrentLang] = React.useState<string>(AVAILABLE_LANGUAGES[0].code);
  const [showLangDropdown, setShowLangDropdown] = React.useState<boolean>(false);
  const [showMobileMenu, setShowMobileMenu] = React.useState<boolean>(false);

  const handleNavLinkClick = (page: PageName, sectionId?: string) => {
    onNavigate(page, sectionId);
    setShowMobileMenu(false); 
  };
  
  const navLinks = [
    { name: 'Home', action: () => handleNavLinkClick('home'), isPrimaryCta: false },
    { name: 'SEO Tools', action: () => handleNavLinkClick('home', 'seo-tools-section'), isPrimaryCta: false },
    { name: 'About Us', action: () => handleNavLinkClick('about'), isPrimaryCta: false },
    { name: 'Contact Us', action: () => handleNavLinkClick('contact'), isPrimaryCta: false },
    { name: 'Feedback', action: () => { onShowFeedback(); setShowMobileMenu(false); }, isPrimaryCta: false },
    // The "Create Now" like button
    { name: 'AI Image Gen', action: () => handleNavLinkClick('home', 'ai-image-studio-section'), isPrimaryCta: true },
  ];
  
  const commonLinkClasses = "px-3 py-2 rounded-md text-sm font-medium text-pf-textMedium hover:text-pf-textLight transition-colors";
  const primaryCtaClasses = "bg-primary hover:bg-primary-dark text-pf-textDark font-semibold px-4 py-2 rounded-lg shadow-md hover:shadow-lg transform transition-all duration-300";
  const mobileLinkClasses = "block px-3 py-2 rounded-md text-base font-medium text-pf-textMedium hover:text-pf-textLight hover:bg-pf-bgLight transition-colors";
  const mobilePrimaryCtaClasses = "block w-full text-center " + primaryCtaClasses;


  return (
    <header className="sticky top-0 z-50 bg-pf-bgDark/80 backdrop-blur-lg shadow-lg border-b border-pf-borderLight">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-3 h-16">
            <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleNavLinkClick('home')}>
                <LogoIcon className="h-8 w-8 text-primary" />
                <h1 className="text-2xl font-bold text-pf-textLight">{APP_NAME}</h1>
            </div>

            {/* Desktop Menu */}
            <nav className="hidden md:flex items-center space-x-1">
                {navLinks.filter(link => !link.isPrimaryCta).map(link => (
                    <button key={link.name} onClick={link.action} className={commonLinkClasses}>
                        {link.name}
                    </button>
                ))}
            </nav>

            <div className="flex items-center space-x-2">
                <div className="relative hidden sm:block">
                    <button 
                    onClick={() => setShowLangDropdown(!showLangDropdown)}
                    className="p-2 rounded-full hover:bg-pf-bgMedium transition-colors"
                    aria-label="Change language"
                    >
                    <LanguageIcon className="h-6 w-6 text-pf-textMedium hover:text-pf-textLight" />
                    </button>
                    {showLangDropdown && (
                    <div className="absolute right-0 mt-2 w-36 bg-pf-bgMedium rounded-md shadow-lg py-1 z-20 border border-pf-borderLight">
                        {AVAILABLE_LANGUAGES.map((lang: Language) => (
                        <button
                            key={lang.code}
                            onClick={() => {setCurrentLang(lang.code); setShowLangDropdown(false); alert(`Language changed to ${lang.name} (UI mock).`)}}
                            className={`block w-full text-left px-4 py-2 text-sm ${
                            currentLang === lang.code 
                                ? 'bg-primary/20 text-primary' 
                                : 'text-pf-textMedium'
                            } hover:bg-primary/10 hover:text-primary`}
                        >
                            {lang.name}
                        </button>
                        ))}
                    </div>
                    )}
                </div>
                
                {/* Dark mode toggle removed */}
                {/* Primary CTA button */}
                <div className="hidden md:block">
                    {navLinks.find(link => link.isPrimaryCta) && (
                        <button 
                            onClick={navLinks.find(link => link.isPrimaryCta)!.action} 
                            className={primaryCtaClasses}
                        >
                            {navLinks.find(link => link.isPrimaryCta)!.name}
                        </button>
                    )}
                </div>


                <div className="md:hidden">
                    <button 
                        onClick={() => setShowMobileMenu(!showMobileMenu)}
                        className="p-2 rounded-full hover:bg-pf-bgMedium transition-colors"
                        aria-label="Open navigation menu"
                        aria-expanded={showMobileMenu}
                    >
                        <MenuIcon className="h-6 w-6 text-pf-textMedium hover:text-pf-textLight" />
                    </button>
                </div>
            </div>
        </div>
        
        {showMobileMenu && (
            <div className="md:hidden py-2 border-t border-pf-borderLight">
                <nav className="flex flex-col space-y-1">
                    {navLinks.map(link => (
                        <button 
                            key={`mobile-${link.name}`} 
                            onClick={link.action} 
                            className={link.isPrimaryCta ? mobilePrimaryCtaClasses : mobileLinkClasses}
                        >
                            {link.name}
                        </button>
                    ))}
                    <div className="pt-2 mt-2 border-t border-pf-borderLight space-y-1">
                         <p className="px-3 text-xs text-pf-textMedium">Language:</p>
                        {AVAILABLE_LANGUAGES.map((lang: Language) => (
                            <button
                                key={`mobile-lang-${lang.code}`}
                                onClick={() => {setCurrentLang(lang.code); setShowLangDropdown(false); alert(`Language changed to ${lang.name} (UI mock).`); setShowMobileMenu(false);}}
                                className={`${mobileLinkClasses} ${ currentLang === lang.code ? 'bg-primary/20 text-primary' : ''}`}
                            >
                                {lang.name}
                            </button>
                        ))}
                    </div>
                </nav>
            </div>
        )}
      </div>
    </header>
  );
};