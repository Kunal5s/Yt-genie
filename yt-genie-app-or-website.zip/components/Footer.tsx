
import React from 'react';
import { APP_NAME } from '../constants';
import { PageName } from '../App'; 

interface FooterProps {
  onNavigate: (page: PageName) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-pf-bgMedium text-pf-textMedium py-12 text-center border-t border-pf-borderLight">
      <div className="container mx-auto px-4">
        {/* Optional: Logo in footer */}
        {/* <div className="flex justify-center mb-4">
            <LogoIcon className="h-10 w-10 text-primary" /> 
        </div> */}
        <p className="text-lg font-semibold text-pf-textLight mb-2">{APP_NAME}</p>
        <p className="text-sm mb-4 max-w-md mx-auto">
          Experience the future of AI image generation with our cutting-edge platform, powered by the latest AI models.
        </p>
        <div className="mb-6 space-x-3 sm:space-x-4">
          <button onClick={() => onNavigate('privacy')} className="hover:text-primary text-sm">Privacy Policy</button>
          <span className="text-pf-textMedium">·</span>
          <button onClick={() => onNavigate('terms')} className="hover:text-primary text-sm">Terms of Service</button>
          <span className="text-pf-textMedium">·</span>
          <button onClick={() => onNavigate('disclaimer')} className="hover:text-primary text-sm">Disclaimer</button>
          <span className="text-pf-textMedium">·</span>
          <button onClick={() => onNavigate('about')} className="hover:text-primary text-sm">About Us</button>
          <span className="text-pf-textMedium">·</span>
          <button onClick={() => onNavigate('contact')} className="hover:text-primary text-sm">Contact Us</button>
        </div>
        <p className="text-xs">&copy; {new Date().getFullYear()} {APP_NAME}. All Rights Reserved (Mock). </p>
        <p className="text-xs mt-1">
          This is a conceptual application for demonstration. Actual YouTube interaction may violate terms.
        </p>
      </div>
    </footer>
  );
};

// Minimalist Logo icon if used in footer
// const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
//   <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
//     <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2ZM8 13.5V10.5C8 9.67 8.67 9 9.5 9h5C15.33 9 16 9.67 16 10.5v3c0 .83-.67 1.5-1.5 1.5h-5C8.67 15 8 14.33 8 13.5Z" />
//   </svg>
// );
