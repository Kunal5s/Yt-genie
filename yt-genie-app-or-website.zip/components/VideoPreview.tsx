
import React from 'react';
import { VideoInfo } from '../types';

interface VideoPreviewProps {
  videoInfo: VideoInfo;
  currentThumbnail: string;
  onImageError?: (fallbackUrl: string) => void;
}

const YouTubeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 28 20" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
    <path d="M27.3242 3.10078C26.9844 1.86523 26.0078 0.916016 24.8008 0.597656C22.6172 0 14 0 14 0C14 0 5.38281 0 3.19922 0.597656C1.99219 0.916016 1.01562 1.86523 0.675781 3.10078C0 5.33008 0 10 0 10C0 10 0 14.6699 0.675781 16.8992C1.01562 18.1348 1.99219 19.084 3.19922 19.4023C5.38281 20 14 20 14 20C14 20 22.6172 20 24.8008 19.4023C26.0078 19.084 26.9844 18.1348 27.3242 16.8992C28 14.6699 28 10 28 10C28 10 28 5.33008 27.3242 3.10078ZM11.1992 14.2008V5.79922L18.4004 10L11.1992 14.2008Z" />
  </svg>
);


export const VideoPreview: React.FC<VideoPreviewProps> = ({ videoInfo, currentThumbnail, onImageError }) => {
  const formatDuration = (isoDuration: string): string => {
    if (!isoDuration || !isoDuration.startsWith('PT')) return 'N/A';
    const timePart = isoDuration.substring(2);
    let hours = 0, minutes = 0, seconds = 0;

    const hourMatch = timePart.match(/(\d+)H/);
    if (hourMatch) hours = parseInt(hourMatch[1]);

    const minuteMatch = timePart.match(/(\d+)M/);
    if (minuteMatch) minutes = parseInt(minuteMatch[1]);
    
    const secondMatch = timePart.match(/(\d+)S/);
    if (secondMatch) seconds = parseInt(secondMatch[1]);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>) => {
    const target = e.target as HTMLImageElement;
    target.onerror = null; 
    const fallbackUrl = `https://picsum.photos/seed/${videoInfo.id}/480/360`;
    target.src = fallbackUrl;
    if (onImageError) {
      onImageError(fallbackUrl); 
    }
  };


  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-semibold text-pf-textLight break-words">{videoInfo.title}</h2>
      <div className="aspect-video w-full rounded-lg overflow-hidden shadow-lg bg-pf-bgLight border border-pf-borderLight">
        <img 
            key={currentThumbnail} 
            src={currentThumbnail} 
            alt={`Thumbnail for ${videoInfo.title}`} 
            className="w-full h-full object-cover"
            onError={handleImageError}
        />
      </div>
      <div className="text-sm text-pf-textMedium space-y-1">
        <p><span className="font-medium text-pf-textLight">Channel:</span> {videoInfo.channelTitle}</p>
        <p><span className="font-medium text-pf-textLight">Duration:</span> {formatDuration(videoInfo.duration)}</p>
      </div>
      <a
        href={`https://www.youtube.com/watch?v=${videoInfo.id}`}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-300 group"
      >
        <YouTubeIcon className="h-5 w-5" />
        <span>Watch on YouTube</span>
        <span className="transform transition-transform duration-300 group-hover:translate-x-1">→</span>
      </a>
    </div>
  );
};