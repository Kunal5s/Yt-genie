
import React from 'react';
import { APP_NAME } from '../constants';

interface SocialShareProps {
  videoUrl?: string | null;
  videoTitle?: string | null;
}

const ShareIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Zm0 0v-.093c0-.663.084-1.3.251-1.907m0 0A2.25 2.25 0 1 1 5.45 7.496a2.25 2.25 0 0 1 1.768 3.411Zm0 0c.044.03.092.055.142.077m1.828 2.918a2.25 2.25 0 1 1 3.824 2.177 2.25 2.25 0 0 1-3.824-2.177Zm0 0c-.417-.763-1.103-1.425-1.93-1.907m0 0A2.25 2.25 0 1 0 5.45 16.504a2.25 2.25 0 0 0 1.768-3.41ZM16.583 7.496a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Zm0 0v.093c0 .663-.084 1.3-.251 1.907m0 0c.417.763 1.103 1.425 1.93 1.907m0 0A2.25 2.25 0 1 1 20.55 10.5a2.25 2.25 0 0 1-1.768-3.411Zm0 0c-.044-.03-.092-.055-.142-.077" />
    </svg>
);


// Basic SVG icons for social media
const TwitterIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733a4.67 4.67 0 002.048-2.578 9.3 9.3 0 01-2.958 1.13 4.66 4.66 0 00-7.95 4.253c-3.88-.195-7.324-2.05-9.633-4.89A4.665 4.665 0 001.29 6.37c0 1.61.82 3.028 2.05 3.865a4.647 4.647 0 01-2.1-.578v.06a4.66 4.66 0 003.738 4.566c-.69.187-1.42.243-2.15.084a4.657 4.657 0 004.348 3.238 9.33 9.33 0 01-5.776 2.001c-.375 0-.745-.022-1.11-.065a13.17 13.17 0 007.14 2.093c8.567 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602a9.49 9.49 0 002.323-2.41z"></path></svg>;
const FacebookIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M22.675 0h-21.35c-.732 0-1.325.593-1.325 1.325v21.351c0 .731.593 1.324 1.325 1.324h11.495v-9.294h-3.128v-3.622h3.128v-2.671c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.795.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.313h3.587l-.467 3.622h-3.12v9.293h6.116c.73 0 1.323-.593 1.323-1.325v-21.35c0-.732-.593-1.325-1.325-1.325z"></path></svg>;
const WhatsAppIcon = () => <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.884-.001 2.225.651 3.891 1.746 5.634l-.999 3.648 3.712-.971zM8.381 9.989c-.034-.054-.521-.251-.736-.436-.215-.185-.381-.22-.602-.22s-.509.158-.736.385c-.227.227-.894.878-1.091 1.074s-.376.299-.552.417c-.176.119-.351.178-.527.06s-1.011-.375-1.928-1.189c-.721-.636-1.202-1.422-1.389-1.669-.186-.247-.004-.381.123-.511.114-.117.248-.299.375-.446.121-.14.171-.248.269-.417.097-.169.047-.305-.027-.425s-.602-.721-.826-.971c-.224-.25-.446-.27-.602-.277-.156-.006-.323-.01-.47-.01s-.396.046-.602.22c-.206.174-.826.801-.826 1.939s.849 2.246.971 2.392c.121.146 1.648 2.542 3.977 3.502 2.019.815 2.438.719 2.887.684.449-.035 1.011-.417 1.157-.826.146-.409.146-.763.102-.826s-.07-.119-.146-.178z"></path></svg>;

export const SocialShare: React.FC<SocialShareProps> = ({ videoUrl, videoTitle }) => {
  const shareUrl = videoUrl || window.location.href; // Fallback to current page URL
  const title = videoTitle || `${APP_NAME} - Check this out!`;
  const encodedUrl = encodeURIComponent(shareUrl);
  const encodedTitle = encodeURIComponent(title);

  const shareLinks = [
    { name: 'Twitter', Icon: TwitterIcon, url: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}` },
    { name: 'Facebook', Icon: FacebookIcon, url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}` },
    { name: 'WhatsApp', Icon: WhatsAppIcon, url: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}` },
  ];

  return (
    <section id="social-share" className="py-6 text-center">
      <h3 className="text-xl font-semibold text-neutral-dark dark:text-neutral-light mb-4 flex items-center justify-center gap-2">
        <ShareIcon className="h-6 w-6"/>
        Share {APP_NAME}
        {videoTitle && " (or this Video)"}
      </h3>
      <div className="flex justify-center space-x-3 sm:space-x-4">
        {shareLinks.map(link => (
          <a
            key={link.name}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Share on ${link.name}`}
            className="p-3 bg-white/70 dark:bg-neutral-dark/70 backdrop-blur-md rounded-full shadow-lg hover:shadow-xl hover:text-primary dark:hover:text-primary-light transform hover:scale-110 transition-all duration-300"
          >
            <link.Icon />
          </a>
        ))}
      </div>
    </section>
  );
};
