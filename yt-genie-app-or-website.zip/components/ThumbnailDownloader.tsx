
import React from 'react';
import { VideoInfo, ThumbnailFormat } from '../types';

interface DownloadIconProps { 
  className?: string;
}

const DownloadIconSvg: React.FC<DownloadIconProps> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
  </svg>
);

export const ThumbnailDownloader: React.FC<ThumbnailDownloaderProps> = ({ videoInfo, currentThumbnailUrl }) => {
  
  const handleDownload = (format: ThumbnailFormat) => {
    const titleForFile = videoInfo?.title || 'yt_genie_image';
    const fileName = `${titleForFile.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_thumbnail.${format}`;
    
    const link = document.createElement('a');
    link.href = currentThumbnailUrl; 
    
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    alert(`Download initiated for: ${fileName} (Format: ${format.toUpperCase()}). This uses the currently displayed image.`);
  };

  return (
    <div className="p-4 bg-pf-bgLight/50 rounded-lg shadow border border-pf-borderLight/50">
      <h3 className="text-lg font-semibold text-pf-textLight mb-3">Download Displayed Thumbnail</h3>
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => handleDownload(ThumbnailFormat.JPEG)}
          className="flex-1 inline-flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
        >
          <DownloadIconSvg className="h-5 w-5" /> JPEG
        </button>
        <button
          onClick={() => handleDownload(ThumbnailFormat.PNG)}
          className="flex-1 inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors duration-300"
        >
          <DownloadIconSvg className="h-5 w-5" /> PNG
        </button>
      </div>
      <p className="text-xs text-pf-textMedium mt-2">Downloads the image currently shown in the main preview.</p>
    </div>
  );
};

interface ThumbnailDownloaderProps { 
  videoInfo: VideoInfo | null; 
  currentThumbnailUrl: string;
}