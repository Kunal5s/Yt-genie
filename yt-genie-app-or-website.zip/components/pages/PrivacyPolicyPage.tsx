
import React from 'react';
import { PageName } from '../../App';
import { APP_NAME } from '../../constants'; // Use global APP_NAME

interface PageProps {
  onNavigate: (page: PageName) => void;
}

export const PrivacyPolicyPage: React.FC<PageProps> = ({ onNavigate }) => {
  const lastUpdated = "October 26, 2023"; // Placeholder date

  return (
    <div className="animate-fade-in bg-pf-bgMedium backdrop-blur-md border border-pf-borderLight p-6 sm:p-8 rounded-xl shadow-xl max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl sm:text-4xl font-bold text-pf-accent text-center mb-2">Privacy Policy</h1>
      <p className="text-center text-sm text-pf-textMedium mb-6">Last Updated: {lastUpdated}</p>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">1. Introduction</h2>
        <p className="text-pf-textLight leading-relaxed">
          Welcome to {APP_NAME} ("we," "us," or "our"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our website and services (collectively, the "Service"). Please read this policy carefully. If you do not agree with the terms of this privacy policy, please do not access the Service.
          <br/><span className="text-pf-accent">[Placeholder: Briefly state your commitment to user privacy and compliance with relevant laws like GDPR, CCPA if applicable. This is a generic placeholder.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">2. Information We Collect</h2>
        <p className="text-pf-textLight leading-relaxed">
          We may collect information about you in a variety of ways. The information we may collect via the Service includes:
        </p>
        <ul className="list-disc list-inside text-pf-textLight space-y-1 mt-2 pl-4">
          <li><strong>YouTube Video URLs:</strong> When you use our service to fetch video information, download thumbnails, or audio (mock), we process the YouTube video URLs you provide.</li>
          <li><strong>User-Provided Prompts:</strong> For AI image generation and SEO content generation, we collect the text prompts and topics you enter.</li>
          <li><strong>Generated Content:</strong> We temporarily store or process AI-generated images and SEO text created through our Service to deliver them to you. <span className="text-pf-accent">[Placeholder: Clarify storage duration if any, or if it's only in-session.]</span></li>
          <li><strong>Customization Preferences:</strong> We store your selected AI image customization filters (styles, moods, etc.) in your browser's local storage to persist your choices across sessions.</li>
          <li><strong>Usage Data (Mock/Placeholder):</strong> We may collect information about how you use the Service, such as features accessed, time spent on pages, and error occurrences. This data is <span className="text-pf-accent">[Placeholder: anonymized/aggregated]</span> and used to improve our Service. <span className="text-pf-accent">[Placeholder: Specify if you use analytics tools like Google Analytics and how.]</span></li>
          <li><strong>Feedback Information:</strong> If you submit feedback via our form, we collect your name and email (if provided) and your message.</li>
          <li><strong>API Key (Environment Variable):</strong> Our application uses an API key for Google Gemini services, which is configured via an environment variable (`process.env.API_KEY`) in the backend or execution environment. This key is not directly collected from users through the UI.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">3. How We Use Your Information</h2>
        <p className="text-pf-textLight leading-relaxed">
          Having accurate information permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Service to:
        </p>
        <ul className="list-disc list-inside text-pf-textLight space-y-1 mt-2 pl-4">
          <li>Provide, operate, and maintain our Service.</li>
          <li>Process your requests for thumbnail/audio downloads (mock for audio) and AI content generation.</li>
          <li>Improve, personalize, and expand our Service.</li>
          <li>Understand and analyze how you use our Service.</li>
          <li>Develop new products, services, features, and functionality.</li>
          <li>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the Service, and for marketing and promotional purposes (with your consent where required).</li>
          <li>Process your feedback and respond to your inquiries.</li>
          <li>Prevent fraudulent activity and ensure the security of our Service.</li>
          <li>Comply with legal obligations.</li>
        </ul>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">4. Disclosure of Your Information</h2>
        <p className="text-pf-textLight leading-relaxed">
          We do not sell your personal information. We may share information we have collected about you in certain situations:
        </p>
        <ul className="list-disc list-inside text-pf-textLight space-y-1 mt-2 pl-4">
          <li><strong>With Third-Party Service Providers:</strong> We use Google's Gemini API (including Imagen) for AI image and text generation. When you use these features, your prompts and relevant data are sent to Google to process your request. We encourage you to review Google's Privacy Policy. <span className="text-pf-accent">[Placeholder: Link to Google's Privacy Policy.]</span></li>
          <li><strong>By Law or to Protect Rights:</strong> If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, and safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.</li>
          <li><strong>Aggregated or Anonymized Data:</strong> We may share aggregated or anonymized information that does not directly identify you with third parties for analysis and service improvement.</li>
        </ul>
         <p className="text-pf-textLight leading-relaxed mt-2">
          <span className="text-pf-accent">[Placeholder: Add other specific disclosures if applicable, e.g., business transfers.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">5. Data Security</h2>
        <p className="text-pf-textLight leading-relaxed">
          We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
          <br/><span className="text-pf-accent">[Placeholder: Briefly mention specific security measures if you can, e.g., HTTPS, data encryption where applicable. Avoid over-promising security.]</span>
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">6. Data Retention</h2>
        <p className="text-pf-textLight leading-relaxed">
         <span className="text-pf-accent">[Placeholder: Describe how long you retain user data. E.g., "We will retain your information only for as long as is necessary for the purposes set out in this privacy policy, or as needed to provide the Service to you. Customization preferences stored in local storage remain until cleared by you or your browser."]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">7. Your Data Rights (Placeholder)</h2>
        <p className="text-pf-textLight leading-relaxed">
          Depending on your jurisdiction, you may have certain rights regarding your personal information, such as the right to access, correct, or delete your data. 
          <br/><span className="text-pf-accent">[Placeholder: Detail user rights like GDPR (access, rectification, erasure, portability) or CCPA (access, deletion, opt-out of sale - note we state we don't sell). Explain how users can exercise these rights, e.g., by contacting you. Be specific if you offer tools for this.]</span>
          For customization filters stored in local storage, you can clear these through your browser settings.
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">8. Cookies and Tracking Technologies</h2>
        <p className="text-pf-textLight leading-relaxed">
          We use local storage to save your AI image customization preferences for a better user experience. We do not currently use cookies for tracking purposes across different websites. 
          <br/><span className="text-pf-accent">[Placeholder: If you use cookies for analytics or other purposes, disclose that here. Explain what types of cookies, why they are used, and how users can manage them.]</span>
          You can typically remove or reject cookies via your browser settings.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">9. Children's Privacy</h2>
        <p className="text-pf-textLight leading-relaxed">
          Our Service is not intended for use by children under the age of 13 (or a higher age threshold as required by applicable law). We do not knowingly collect personal information from children under 13. If we become aware that a child under 13 has provided us with personal information, we will take steps to delete such information.
          <br/><span className="text-pf-accent">[Placeholder: If your service might be used by children or has different age restrictions (e.g., 16 for GDPR without parental consent for certain processing), adjust this section accordingly.]</span>
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">10. Changes to This Privacy Policy</h2>
        <p className="text-pf-textLight leading-relaxed">
          We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">11. Contact Us</h2>
        <p className="text-pf-textLight leading-relaxed">
          If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:
          <br/><span className="text-pf-accent">[Placeholder: privacy@ytgenie.example.com]</span>
          <br/><span className="text-pf-accent">[Placeholder: Or link to your Contact Us page/form.]</span>
        </p>
      </section>

      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('home')}
          className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
