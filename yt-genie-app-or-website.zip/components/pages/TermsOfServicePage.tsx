
import React from 'react';
import { PageName } from '../../App';
import { APP_NAME } from '../../constants'; // Use global APP_NAME

interface PageProps {
  onNavigate: (page: PageName) => void;
}

export const TermsOfServicePage: React.FC<PageProps> = ({ onNavigate }) => {
  const effectiveDate = "October 26, 2023"; // Placeholder date

  return (
    <div className="animate-fade-in bg-pf-bgMedium backdrop-blur-md border border-pf-borderLight p-6 sm:p-8 rounded-xl shadow-xl max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl sm:text-4xl font-bold text-pf-accent text-center mb-2">Terms of Service</h1>
      <p className="text-center text-sm text-pf-textMedium mb-6">Effective Date: {effectiveDate}</p>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">1. Acceptance of Terms</h2>
        <p className="text-pf-textLight leading-relaxed">
          By accessing or using {APP_NAME} (the "Service"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to all of these Terms, do not use the Service. These Terms apply to all visitors, users, and others who access or use the Service.
          <br/><span className="text-pf-accent">[Placeholder: Add any specific conditions for acceptance, e.g., age requirements if different from children's privacy.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">2. Description of Service</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} provides a suite of tools for YouTube content creators, including but not limited to: YouTube thumbnail and audio downloading (audio download is a mock feature), AI-powered thumbnail generation using Google Imagen, live thumbnail editing, and AI-driven SEO content generation (titles, descriptions, tags, etc.) using Google Gemini.
          <br/><span className="text-pf-accent">[Placeholder: Ensure this description accurately reflects all current and mock features. Mention that some features are mock/demonstrative.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">3. User Responsibilities and Conduct</h2>
        <p className="text-pf-textLight leading-relaxed">
          You agree to use the Service only for lawful purposes and in accordance with these Terms. You are solely responsible for:
        </p>
        <ul className="list-disc list-inside text-pf-textLight space-y-1 mt-2 pl-4">
          <li><strong>Compliance with YouTube's Terms:</strong> When downloading thumbnails or audio (mock) from YouTube, you must comply with YouTube's Terms of Service. {APP_NAME} is a tool, and its use does not grant you any rights to YouTube content that you do not otherwise possess. Unauthorized downloading or use of copyrighted material is prohibited.</li>
          <li><strong>Copyright and Intellectual Property:</strong> Respecting the intellectual property rights of others. Do not use the Service to create, share, or distribute content that infringes on any copyright, trademark, or other proprietary rights.</li>
          <li><strong>Content You Create:</strong> Any content you generate using {APP_NAME} (e.g., AI images, SEO text) is your responsibility. You affirm that you have the necessary rights to any prompts you provide and that your use of generated content complies with all applicable laws and third-party terms (including AI service provider terms).</li>
          <li><strong>Prohibited Uses:</strong> You agree not to use the Service to: <span className="text-pf-accent">[Placeholder: List prohibited activities, e.g., generate harmful, illegal, or offensive content; reverse engineer the service; introduce malware; overload servers; use for spamming; impersonate others.]</span></li>
        </ul>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">4. API Usage and Third-Party Services</h2>
        <p className="text-pf-textLight leading-relaxed">
          The Service utilizes third-party APIs, including Google Gemini and Imagen APIs, for its AI-powered features. Your use of these features is also subject to the terms and policies of these third-party providers. 
          <br/><span className="text-pf-accent">[Placeholder: Link to Google AI Terms or relevant policies.]</span>
          We are not responsible for the availability, accuracy, or practices of these third-party services. The API key for these services is managed through an environment variable (`process.env.API_KEY`) and is not collected from users via the UI.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">5. Intellectual Property Rights</h2>
        <p className="text-pf-textLight leading-relaxed">
          The Service and its original content (excluding content generated by users or sourced from third parties like YouTube), features, and functionality are and will remain the exclusive property of {APP_NAME} and its licensors. The Service is protected by copyright, trademark, and other laws of <span className="text-pf-accent">[Placeholder: Your Country/Jurisdiction]</span> and foreign countries. Our trademarks and trade dress may not be used in connection with any product or service without our prior written consent.
          <br/><strong>User-Generated Content:</strong> You retain ownership of the prompts you provide and the content you generate using the AI tools, subject to the terms of the AI service providers (e.g., Google). <span className="text-pf-accent">[Placeholder: Clarify if you claim any license to user-generated content, e.g., for service improvement, typically not for public display without consent.]</span>
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">6. Disclaimers and Limitation of Liability</h2>
        <p className="text-pf-textLight leading-relaxed">
          <strong>"AS IS" Basis:</strong> The Service is provided on an "AS IS" and "AS AVAILABLE" basis. {APP_NAME} makes no warranties, express or implied, regarding the operation or availability of the Service, or the information, content, materials, or products included therein.
          <br/><strong>No Guarantee of Accuracy or Results:</strong> AI-generated content can be unpredictable and may sometimes produce inaccurate, incomplete, or offensive results. You should review and verify all AI-generated content before use. We do not guarantee any specific outcomes from using our SEO tools or thumbnail generators.
          <br/><strong>Limitation of Liability:</strong> To the fullest extent permitted by applicable law, in no event shall {APP_NAME}, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from (i) your access to or use of or inability to access or use the Service; (ii) any conduct or content of any third party on the Service; (iii) any content obtained from the Service; and (iv) unauthorized access, use, or alteration of your transmissions or content, whether based on warranty, contract, tort (including negligence), or any other legal theory, whether or not we have been informed of the possibility of such damage.
          <br/><span className="text-pf-accent">[Placeholder: Consider adding a cap on direct damages if legally advised, e.g., to the amount you paid, if any.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">7. Termination</h2>
        <p className="text-pf-textLight leading-relaxed">
          We may terminate or suspend your access to our Service immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms. Upon termination, your right to use the Service will immediately cease.
          <br/><span className="text-pf-accent">[Placeholder: Specify any provisions that survive termination, e.g., intellectual property, disclaimers, limitation of liability.]</span>
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">8. Governing Law</h2>
        <p className="text-pf-textLight leading-relaxed">
          These Terms shall be governed and construed in accordance with the laws of <span className="text-pf-accent">[Placeholder: Your State/Country/Jurisdiction]</span>, without regard to its conflict of law provisions.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">9. Changes to Terms</h2>
        <p className="text-pf-textLight leading-relaxed">
          We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material, we will try to provide at least <span className="text-pf-accent">[Placeholder: e.g., 30 days']</span> notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">10. Contact Us</h2>
        <p className="text-pf-textLight leading-relaxed">
          If you have any questions about these Terms, please contact us at:
          <br/><span className="text-pf-accent">[Placeholder: legal@ytgenie.example.com or link to Contact Us page.]</span>
        </p>
      </section>

      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('home')}
          className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
