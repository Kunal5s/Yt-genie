
import React from 'react';
import { PageName } from '../../App';
import { APP_NAME } from '../../constants'; // Use global APP_NAME

interface PageProps {
  onNavigate: (page: PageName) => void;
}

export const AboutUsPage: React.FC<PageProps> = ({ onNavigate }) => {
  return (
    <div className="animate-fade-in bg-pf-bgMedium backdrop-blur-md border border-pf-borderLight p-6 sm:p-8 rounded-xl shadow-xl max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl sm:text-4xl font-bold text-pf-accent text-center mb-6">About {APP_NAME}</h1>
      
      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Our Mission</h2>
        <p className="text-pf-textLight leading-relaxed">
          Welcome to {APP_NAME}, your all-in-one toolkit designed to empower YouTube creators and digital marketers. Our mission is to simplify your content creation workflow, boost your channel's visibility, and help you engage your audience more effectively. We believe that great content deserves great presentation and optimal reach, and {APP_NAME} provides the tools to achieve just that. From generating eye-catching thumbnails with advanced AI to crafting SEO-optimized video descriptions, we're here to support your creative journey every step of the way.
        </p>
        <p className="text-pf-textLight leading-relaxed mt-2">
          We strive to provide cutting-edge solutions by integrating powerful technologies like Google's Imagen for AI image generation and sophisticated algorithms for SEO content creation. Our goal is to level the playing field, giving every creator access to tools that were once complex or expensive.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">The Story Behind {APP_NAME}</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} was born from a simple observation: many talented creators struggle with the technical aspects of content promotion and optimization. <span className="text-pf-accent">[Placeholder: Insert a brief, engaging story about the founder's inspiration or the problem that sparked the idea for YT Genie. E.g., "As a former content creator myself, I experienced firsthand the challenges of designing compelling thumbnails and writing descriptions that rank. I knew there had to be a better way..."]</span> This realization fueled the development of a comprehensive platform that addresses these pain points directly.
        </p>
        <p className="text-pf-textLight leading-relaxed mt-2">
          Our journey involved extensive research, collaboration with creators, and a commitment to building a user-friendly experience. We are passionate about innovation and continuously seek to enhance {APP_NAME} with new features and improvements based on user feedback and emerging trends in the digital landscape.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">What We Offer</h2>
        <ul className="list-disc list-inside text-pf-textLight space-y-2 leading-relaxed pl-4">
          <li><strong>AI Thumbnail Generation:</strong> Create stunning, unique thumbnails using Google's Imagen technology. Customize styles, moods, lighting, and colors to perfectly match your video's content and brand.</li>
          <li><strong>YouTube Thumbnail & Audio Downloader:</strong> Easily download existing YouTube video thumbnails in various qualities or fetch audio tracks (for personal use, respecting YouTube's TOS - audio is a mock feature).</li>
          <li><strong>Live Thumbnail Editor:</strong> Fine-tune your thumbnails with text overlays, filters, and other editing tools directly within the app.</li>
          <li><strong>AI SEO Content Generator:</strong> Automatically generate SEO-friendly titles, descriptions, tags, keywords, viral hooks, and content ideas based on your video topic.</li>
          <li><strong>User-Friendly Interface:</strong> A sleek, responsive design that works seamlessly across all devices.</li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Our Vision for the Future</h2>
        <p className="text-pf-textLight leading-relaxed">
          We envision {APP_NAME} becoming the go-to platform for YouTube creators worldwide, constantly evolving to meet the dynamic needs of the content creation community. <span className="text-pf-accent">[Placeholder: Expand on future plans, e.g., "We are working on integrating more advanced analytics, community features, and AI-driven content strategy tools..."]</span> Our commitment is to your success, and we're excited to grow with you.
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Our Team (Placeholder)</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} is developed and maintained by a passionate team of engineers, designers, and content strategists dedicated to building high-quality tools for creators. <span className="text-pf-accent">[Placeholder: Add a brief mention of the team's expertise or values. E.g., "We combine technical expertise with a deep understanding of the creator economy..."]</span> We value creativity, innovation, and user feedback above all.
        </p>
      </section>

      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('home')}
          className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
