
import React from 'react';
import { PageName } from '../../App';
import { APP_NAME } from '../../constants'; // Use global APP_NAME

interface PageProps {
  onNavigate: (page: PageName) => void;
  onShowFeedback: () => void; // To trigger the feedback modal
}

export const ContactUsPage: React.FC<PageProps> = ({ onNavigate, onShowFeedback }) => {
  return (
    <div className="animate-fade-in bg-pf-bgMedium backdrop-blur-md border border-pf-borderLight p-6 sm:p-8 rounded-xl shadow-xl max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl sm:text-4xl font-bold text-pf-accent text-center mb-6">Contact Us</h1>
      
      <section>
        <p className="text-pf-textLight leading-relaxed text-lg text-center mb-6">
          We'd love to hear from you! Whether you have a question about our features, need assistance, have a suggestion, or want to discuss partnership opportunities, please feel free to reach out.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">General Inquiries & Support</h2>
        <p className="text-pf-textLight leading-relaxed">
          For general questions, support requests, or technical assistance with {APP_NAME}, the best way to get in touch is by using our feedback form. This helps us track your query efficiently and ensure a timely response.
        </p>
        <div className="text-center my-4">
            <button
                onClick={onShowFeedback}
                className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-3 px-8 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 text-lg"
            >
                Open Feedback & Support Form
            </button>
        </div>
        <p className="text-pf-textLight leading-relaxed mt-2">
          Alternatively, you can email us at: <strong className="text-pf-accent">[Placeholder: support@ytgenie.example.com]</strong>. We aim to respond to all inquiries within 24-48 business hours. Please provide as much detail as possible so we can assist you effectively.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Business & Partnership Inquiries</h2>
        <p className="text-pf-textLight leading-relaxed">
          If you are interested in business collaborations, partnerships, or media inquiries, please contact our business development team at: <strong className="text-pf-accent">[Placeholder: partnerships@ytgenie.example.com]</strong>.
          We are always open to exploring opportunities that align with our mission to empower content creators.
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Connect With Us (Placeholder)</h2>
        <p className="text-pf-textLight leading-relaxed">
          Follow us on our social media channels to stay updated on the latest features, tips, and news from {APP_NAME}.
        </p>
        <ul className="list-none space-y-2 mt-3 pl-4">
            <li><strong className="text-pf-accent">[Placeholder: Twitter/X: @YTGenieApp]</strong></li>
            <li><strong className="text-pf-accent">[Placeholder: Facebook: /YTGenieOfficial]</strong></li>
            <li><strong className="text-pf-accent">[Placeholder: Instagram: @yt_genie_app]</strong></li>
        </ul>
         <p className="text-pf-textMedium leading-relaxed mt-2 text-sm">
           (Note: These are placeholder social media links. Please replace with your actual profiles.)
        </p>
      </section>
      
      <section>
        <h2 className="text-2xl font-semibold text-pf-textLight mb-3 border-b border-pf-borderLight pb-2">Our Office (Placeholder)</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} Headquarters <br/>
          <span className="text-pf-accent">[Placeholder: 123 Creator Lane <br/>
          Innovation City, CA 90210 <br/>
          United States]</span>
        </p>
        <p className="text-pf-textMedium leading-relaxed mt-2 text-sm">
          (Please note: Office visits are by appointment only. For most inquiries, please use the email addresses or feedback form provided above.)
        </p>
      </section>

      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('home')}
          className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
