
import React from 'react';
import { PageName } from '../../App';
import { APP_NAME } from '../../constants'; // Use global APP_NAME

interface PageProps {
  onNavigate: (page: PageName) => void;
}

export const DisclaimerPage: React.FC<PageProps> = ({ onNavigate }) => {
  const lastUpdated = "October 26, 2023"; // Placeholder date

  return (
    <div className="animate-fade-in bg-pf-bgMedium backdrop-blur-md border border-pf-borderLight p-6 sm:p-8 rounded-xl shadow-xl max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl sm:text-4xl font-bold text-pf-accent text-center mb-2">Disclaimer</h1>
      <p className="text-center text-sm text-pf-textMedium mb-6">Last Updated: {lastUpdated}</p>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">1. General Information</h2>
        <p className="text-pf-textLight leading-relaxed">
          The information provided by {APP_NAME} (the "Service") is for general informational and demonstrational purposes only. All information on the Service is provided in good faith; however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the Service.
          <br/><span className="text-pf-accent">[Placeholder: This is a standard disclaimer opening. Tailor if needed.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">2. No Professional Advice</h2>
        <p className="text-pf-textLight leading-relaxed">
          The Service cannot and does not contain professional advice (e.g., legal, financial, or marketing advice). The information, including AI-generated content, is provided for general informational and educational purposes only and is not a substitute for professional advice. Accordingly, before taking any actions based upon such information, we encourage you to consult with the appropriate professionals. We do not provide any kind of professional advice. The use or reliance of any information contained on this site is solely at your own risk.
          <br/><span className="text-pf-accent">[Placeholder: Emphasize that AI content is not professional advice and should be reviewed.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">3. AI-Generated Content</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} utilizes artificial intelligence (AI) models, including Google Imagen and Gemini, to generate images, titles, descriptions, tags, and other content. While we strive to use advanced AI, please be aware that:
        </p>
        <ul className="list-disc list-inside text-pf-textLight space-y-1 mt-2 pl-4">
          <li><strong>Accuracy and Completeness:</strong> AI-generated content may not always be accurate, complete, or up-to-date. It can sometimes produce unexpected, biased, or incorrect information.</li>
          <li><strong>Review Required:</strong> You are solely responsible for reviewing, editing, and verifying all AI-generated content for accuracy, appropriateness, and compliance with any applicable laws or guidelines before using or publishing it.</li>
          <li><strong>No Endorsement:</strong> The generation of content by AI does not constitute an endorsement by {APP_NAME} of such content.</li>
          <li><strong>Originality:</strong> While AI aims to create unique content, there is no guarantee that generated content will be entirely original or free from similarities to existing works. Users are responsible for ensuring their use of generated content does not infringe on third-party rights.</li>
        </ul>
         <p className="text-pf-textLight leading-relaxed mt-2">
          <span className="text-pf-accent">[Placeholder: Add any specific warnings or disclaimers related to the AI models used, if provided by the AI service provider (e.g., Google's usage guidelines for Gemini/Imagen).]</span>
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">4. Third-Party Links and Services</h2>
        <p className="text-pf-textLight leading-relaxed">
          The Service may contain links to other websites or content belonging to or originating from third parties, or links to websites and features in banners or other advertising. Such external links are not investigated, monitored, or checked for accuracy, adequacy, validity, reliability, availability, or completeness by us.
          <br/>We do not warrant, endorse, guarantee, or assume responsibility for the accuracy or reliability of any information offered by third-party websites linked through the site or any website or feature linked in any banner or other advertising. We will not be a party to or in any way be responsible for monitoring any transaction between you and third-party providers of products or services.
          <br/>This includes your interactions with YouTube (you must adhere to their Terms of Service) and Google (for AI services, subject to their terms).
        </p>
      </section>

       <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">5. YouTube Terms of Service and Content Usage</h2>
        <p className="text-pf-textLight leading-relaxed">
          {APP_NAME} provides tools that interact with YouTube content (e.g., thumbnail downloader, audio downloader - mock feature). Users are reminded that they are solely responsible for ensuring their use of such tools and any downloaded content complies with YouTube's Terms of Service, copyright laws, and any other applicable regulations. {APP_NAME} does not endorse or encourage any activity that violates YouTube's policies or infringes on copyright. The audio download feature is for demonstration purposes and actual implementation would require careful legal and technical consideration.
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">6. Limitation of Liability</h2>
        <p className="text-pf-textLight leading-relaxed">
          Under no circumstance shall we have any liability to you for any loss or damage of any kind incurred as a result of the use of the Service or reliance on any information provided on the Service. Your use of the Service and your reliance on any information on the Service is solely at your own risk.
          <br/>(Please also refer to the Limitation of Liability section in our Terms of Service.)
        </p>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">7. Errors and Omissions</h2>
        <p className="text-pf-textLight leading-relaxed">
          While we strive to make the information provided by the Service as accurate as possible, the Service may contain errors or omissions. We reserve the right to correct any errors, inaccuracies, or omissions and to change or update the information on the Service at any time, without prior notice.
           <br/><span className="text-pf-accent">[Placeholder: Add anything specific about potential errors from mock data or calculations if relevant.]</span>
        </p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-pf-textLight mb-2 border-b border-pf-borderLight pb-1">8. Contact Us</h2>
        <p className="text-pf-textLight leading-relaxed">
          If you have any questions or concerns regarding this Disclaimer, please contact us through our Contact Us page or at <span className="text-pf-accent">[Placeholder: legal@ytgenie.example.com]</span>.
        </p>
      </section>

      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate('home')}
          className="bg-pf-accent hover:bg-pf-accentHover text-pf-textDark font-semibold py-2.5 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
