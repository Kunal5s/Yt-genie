
import React, { useState } from 'react';

interface SearchBarProps {
  onSearch: (url: string) => void;
  isLoading: boolean;
}

const SearchIcon: React.FC<{className?: string}> = ({className}) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
  </svg>
);


export const SearchBar: React.FC<SearchBarProps> = ({ onSearch, isLoading }) => {
  const [url, setUrl] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(url);
  };

  return (
    <div className="max-w-2xl mx-auto bg-pf-bgMedium p-6 rounded-xl shadow-xl border border-pf-borderLight">
      <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-4">
        <div className="relative flex-grow w-full">
           <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-pf-textMedium" />
          </div>
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Enter YouTube Video URL (e.g., https://www.youtube.com/watch?v=...)"
            className="w-full pl-10 pr-4 py-3 rounded-lg border border-pf-borderLight focus:border-primary bg-pf-bgLight text-pf-textLight placeholder-pf-textMedium focus:ring-2 focus:ring-primary outline-none transition-all duration-300 shadow-sm"
            required
            aria-label="YouTube Video URL"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full sm:w-auto bg-primary hover:bg-primary-dark text-pf-textDark font-semibold py-3 px-8 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {isLoading ? 'Loading...' : 'Fetch Video'}
        </button>
      </form>
      <p className="text-xs text-center mt-3 text-pf-textMedium">
        Example: https://www.youtube.com/watch?v=dQw4w9WgXcQ
      </p>
    </div>
  );
};