
import React from 'react';
import { GeneratedContent } from '../types';

interface SeoContentGeneratorProps {
  userPrompt: string;
  onUserPromptChange: (prompt: string) => void;
  onGenerate: () => void;
  generatedContent: GeneratedContent | null;
  isLoading: boolean;
  contextPrompt?: string; // Used for dynamic button text: user's SEO prompt, video title, or AI image prompt
}

// FIX: Moved copyToClipboard function to module scope
const copyToClipboard = (text: string | string[], type: string) => {
  let textToCopy: string;
  if (Array.isArray(text)) {
      textToCopy = text.join(', '); // For tags, keywords, hooks, ideas
  } else {
      textToCopy = text;
  }

  if (!textToCopy) {
      alert(`No ${type} to copy.`);
      return;
  }
  navigator.clipboard.writeText(textToCopy)
    .then(() => alert(`${type} copied to clipboard!`))
    .catch(err => {
      console.error('Failed to copy: ', err);
      alert(`Failed to copy ${type}. See console for details.`);
    });
};

const ClipboardIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
  </svg>
);

const LightbulbIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 0 0 1.5-.189m-1.5.189a6.01 6.01 0 0 1-1.5-.189m3.75 7.478a12.06 12.06 0 0 1-4.5 0m3.75 2.354a15.055 15.055 0 0 1-4.5 0M12 3v2.25m0 0a6.01 6.01 0 0 0 1.5.189m-1.5-.189a6.01 6.01 0 0 1-1.5-.189M12 21a9.01 9.01 0 0 0 6.364-2.636M12 21a9.01 9.01 0 0 1-6.364-2.636M12 21V3m0 18h.01M12 3h.01M12 3a9.01 9.01 0 0 0-6.364 2.636M12 3a9.01 9.01 0 0 1 6.364 2.636m0 0H12m6.364 0H12m12.728 0l1.414-1.414M5.636 5.636l1.414-1.414M21.364 18.364l-1.414-1.414M11.25 18.75a.75.75 0 0 0 1.5 0V12m0 0a.75.75 0 0 0-1.5 0V12Z" />
    </svg>
);


const TagChip: React.FC<{text: string, className?: string}> = ({ text, className }) => (
  <span className={`text-xs font-medium px-2.5 py-1 rounded-full ${className || 'bg-secondary/20 text-secondary-dark dark:bg-secondary-dark/40 dark:text-secondary-light'}`}>
    {text}
  </span>
);


export const SeoContentGenerator: React.FC<SeoContentGeneratorProps> = ({ 
    userPrompt, onUserPromptChange, onGenerate, generatedContent, isLoading, contextPrompt 
}) => {
  
  const seoButtonText = contextPrompt 
    ? `✨ Generate SEO for "${contextPrompt.substring(0,30)}..."` 
    : '✨ Generate SEO (Provide Topic Above)';

  return (
    <div className="">
      <h2 className="text-2xl sm:text-3xl font-bold text-primary dark:text-primary-light mb-4 text-center">
        <LightbulbIcon className="inline-block h-7 w-7 mr-2 align-text-bottom" />
        AI SEO Content Studio
      </h2>
      
      <div className="mb-4">
        <label htmlFor="userSeoPrompt" className="block text-sm font-medium text-neutral-dark dark:text-neutral-light mb-1">
          Your SEO Topic / Idea / Video Title:
        </label>
        <textarea
          id="userSeoPrompt"
          rows={3}
          value={userPrompt}
          onChange={(e) => onUserPromptChange(e.target.value)}
          placeholder="e.g., A tutorial on making viral TikTok videos, a review of the latest iPhone, my trip to Japan..."
          className="w-full p-2.5 border border-gray-300 dark:border-gray-600 rounded-lg bg-neutral-light/50 dark:bg-gray-700/80 text-neutral-dark dark:text-neutral-light focus:ring-primary focus:border-primary dark:focus:ring-primary-light dark:focus:border-primary-light shadow-sm"
        />
      </div>

      <button
        onClick={onGenerate}
        disabled={isLoading || !userPrompt.trim()}
        className="w-full bg-gradient-to-r from-accent to-green-600 hover:from-accent-dark hover:to-green-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 disabled:opacity-60 text-sm sm:text-base disabled:cursor-not-allowed"
        title={contextPrompt ? `Generate SEO for "${contextPrompt}"` : 'Enter a topic above to generate SEO content'}
      >
        {isLoading ? 'Generating with AI...' : seoButtonText}
      </button>

      {generatedContent && !isLoading && (
        <div className="mt-6 space-y-6 p-4 bg-neutral-light/50 dark:bg-gray-700/50 rounded-lg animate-fade-in">
          
          {/* Title */}
          <SeoOutputField fieldName="Generated Title" content={generatedContent.title} onCopy={() => copyToClipboard(generatedContent.title || '', 'Title')} />

          {/* Description */}
          <SeoOutputField fieldName="Generated Description" content={generatedContent.description} onCopy={() => copyToClipboard(generatedContent.description || '', 'Description')} isPreformatted={true} maxHeight="max-h-48"/>
          
          {/* Tags */}
          <SeoOutputChipArrayField fieldName="Generated Tags" items={generatedContent.tags} onCopyAll={() => copyToClipboard(generatedContent.tags || [], 'Tags')} chipClassName="bg-secondary/20 text-secondary-dark dark:bg-secondary-dark/40 dark:text-secondary-light" />

          {/* Keywords */}
          <SeoOutputChipArrayField fieldName="Generated Keywords" items={generatedContent.keywords} onCopyAll={() => copyToClipboard(generatedContent.keywords || [], 'Keywords')} chipClassName="bg-primary/20 text-primary-dark dark:bg-primary-dark/40 dark:text-primary-light" />

          {/* Viral Hooks */}
          <SeoOutputListField fieldName="Viral Hooks" items={generatedContent.viralHooks} onCopyAll={() => copyToClipboard(generatedContent.viralHooks || [], 'Viral Hooks')} />
          
          {/* Content Ideas */}
          <SeoOutputListField fieldName="Content Ideas" items={generatedContent.contentIdeas} onCopyAll={() => copyToClipboard(generatedContent.contentIdeas || [], 'Content Ideas')} />

        </div>
      )}
      <p className="text-xs text-center mt-3 text-gray-500 dark:text-gray-400">
        Powered by AI. Always review and refine content for accuracy and your unique brand voice.
      </p>
    </div>
  );
};

// Helper sub-components for displaying SEO fields
interface SeoOutputFieldProps {
    fieldName: string;
    content: string | undefined;
    onCopy: () => void;
    isPreformatted?: boolean;
    maxHeight?: string;
}
const SeoOutputField: React.FC<SeoOutputFieldProps> = ({ fieldName, content, onCopy, isPreformatted, maxHeight }) => {
    if (!content) return null;
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <h4 className="font-semibold text-neutral-dark dark:text-neutral-light">{fieldName}:</h4>
                <button onClick={onCopy} className="text-sm text-accent hover:text-accent-dark p-1 rounded flex items-center gap-1" title={`Copy ${fieldName.toLowerCase()}`} aria-label={`Copy ${fieldName.toLowerCase()}`}>
                    <ClipboardIcon className="h-5 w-5"/> Copy
                </button>
            </div>
            <p className={`text-sm p-2.5 bg-white dark:bg-gray-600 rounded shadow break-words min-h-[2.5em] ${isPreformatted ? 'whitespace-pre-line' : ''} ${maxHeight || ''} ${maxHeight ? 'overflow-y-auto' : ''}`}>
                {content}
            </p>
        </div>
    );
};

interface SeoOutputChipArrayFieldProps {
    fieldName: string;
    items: string[] | undefined;
    onCopyAll: () => void;
    chipClassName?: string;
}
const SeoOutputChipArrayField: React.FC<SeoOutputChipArrayFieldProps> = ({ fieldName, items, onCopyAll, chipClassName }) => {
    if (!items || items.length === 0) return null;
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <h4 className="font-semibold text-neutral-dark dark:text-neutral-light">{fieldName}:</h4>
                <button onClick={onCopyAll} className="text-sm text-accent hover:text-accent-dark p-1 rounded flex items-center gap-1" title={`Copy all ${fieldName.toLowerCase()}`} aria-label={`Copy all ${fieldName.toLowerCase()}`}>
                    <ClipboardIcon className="h-5 w-5"/> Copy All
                </button>
            </div>
            <div className="mt-1 p-2.5 bg-white dark:bg-gray-600 rounded shadow flex flex-wrap gap-2">
                {items.map((item, index) => <TagChip key={`${fieldName}-${index}`} text={item} className={chipClassName} />)}
            </div>
        </div>
    );
};

interface SeoOutputListFieldProps {
    fieldName: string;
    items: string[] | undefined;
    onCopyAll: () => void;
}
const SeoOutputListField: React.FC<SeoOutputListFieldProps> = ({ fieldName, items, onCopyAll }) => {
    if (!items || items.length === 0) return null;
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <h4 className="font-semibold text-neutral-dark dark:text-neutral-light">{fieldName}:</h4>
                 <button onClick={onCopyAll} className="text-sm text-accent hover:text-accent-dark p-1 rounded flex items-center gap-1" title={`Copy all ${fieldName.toLowerCase()}`} aria-label={`Copy all ${fieldName.toLowerCase()}`}>
                    <ClipboardIcon className="h-5 w-5"/> Copy All
                </button>
            </div>
            <ul className="list-disc list-inside mt-1 p-2.5 bg-white dark:bg-gray-600 rounded shadow space-y-1.5">
                {items.map((item, index) => (
                    <li key={`${fieldName}-item-${index}`} className="text-sm flex items-start">
                        <span className="mr-2 text-accent dark:text-accent-light">&#8227;</span> 
                        <span className="flex-1">{item}</span>
                        <button onClick={() => copyToClipboard(item, fieldName.slice(0,-1))} className="ml-2 text-xs text-accent/80 hover:text-accent p-0.5 rounded flex items-center gap-0.5" title={`Copy this ${fieldName.slice(0,-1).toLowerCase()}`} aria-label={`Copy this ${fieldName.slice(0,-1).toLowerCase()}`}>
                            <ClipboardIcon className="h-3.5 w-3.5"/> Copy
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};