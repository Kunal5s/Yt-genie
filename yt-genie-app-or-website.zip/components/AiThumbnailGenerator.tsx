
import React from 'react';
import { AspectRatio, AiCustomizationFilters, AiCustomizationFilterCategory } from '../types';
// FIX: Import NUMBER_OF_IMAGES_TO_GENERATE
import { AVAILABLE_ASPECT_RATIOS, NUMBER_OF_IMAGES_TO_GENERATE } from '../constants';
import { AiImageCustomizationPanel } from './AiImageCustomizationPanel';

interface AiImageGeneratorControlsProps {
  prompt: string;
  onPromptChange: (prompt: string) => void;
  aspectRatio: AspectRatio;
  onAspectRatioChange: (aspectRatio: AspectRatio) => void;
  customizationFilters: AiCustomizationFilters;
  onCustomizationFilterChange: (category: AiCustomizationFilterCategory, value: string) => void;
  onGenerate: (prompt: string, aspectRatio: AspectRatio, filters: AiCustomizationFilters) => void;
  isLoading: boolean;
}

const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 7.5l1.406-3.281 3.281-1.406L21.537 6l-1.406 3.281-3.281 1.406L15 9.336l1.406-3.281L18.25 7.5z" />
  </svg>
);


export const AiImageGeneratorControls: React.FC<AiImageGeneratorControlsProps> = ({
  prompt,
  onPromptChange,
  aspectRatio,
  onAspectRatioChange,
  customizationFilters,
  onCustomizationFilterChange,
  onGenerate,
  isLoading,
}) => {
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(prompt, aspectRatio, customizationFilters);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="aiPrompt" className="block text-sm font-medium text-pf-textMedium mb-1">
          Describe Your Image
        </label>
        <textarea
          id="aiPrompt"
          rows={4}
          value={prompt}
          onChange={(e) => onPromptChange(e.target.value)}
          placeholder="e.g., A futuristic robot holding a glowing YouTube play button, cinematic lighting, hyperrealistic..."
          className="w-full p-3 border border-pf-borderLight rounded-lg bg-pf-bgLight text-pf-textLight placeholder-pf-textMedium focus:ring-2 focus:ring-primary focus:border-primary shadow-sm"
          required
        />
         <p className="text-xs text-pf-textMedium mt-1">Be specific about subjects, style, lighting, composition, and mood for best results.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="aspectRatio" className="block text-sm font-medium text-pf-textMedium mb-1">
            Aspect Ratio
          </label>
          <select
            id="aspectRatio"
            value={aspectRatio}
            onChange={(e) => onAspectRatioChange(e.target.value as AspectRatio)}
            className="w-full p-3 border border-pf-borderLight rounded-lg bg-pf-bgLight text-pf-textLight focus:ring-primary focus:border-primary shadow-sm appearance-none"
          >
            {AVAILABLE_ASPECT_RATIOS.map(ar => (
              <option key={ar.value} value={ar.value} className="bg-pf-bgLight text-pf-textLight">{ar.label}</option>
            ))}
          </select>
        </div>
        {/* Placeholder for another control like "Style Preset" from screenshot if needed later */}
        {/* <div>
          <label htmlFor="stylePreset" className="block text-sm font-medium text-pf-textMedium mb-1">
            Style Preset
          </label>
          <select id="stylePreset" className="w-full p-3 border border-pf-borderLight rounded-lg bg-pf-bgLight text-pf-textLight focus:ring-primary focus:border-primary shadow-sm appearance-none">
            <option className="bg-pf-bgLight text-pf-textLight">Cinematic</option>
            <option className="bg-pf-bgLight text-pf-textLight">Photorealistic</option>
            <option className="bg-pf-bgLight text-pf-textLight">Anime</option>
          </select>
        </div> */}
      </div>
      

      <AiImageCustomizationPanel 
        selectedFilters={customizationFilters}
        onFilterChange={onCustomizationFilterChange}
      />
      
      {/* Sliders - basic styling with accent color */}
      {/* <div>
        <label htmlFor="quality" className="block text-sm font-medium text-pf-textMedium mb-1">Quality Level: <span className="text-pf-textLight">80%</span></label>
        <input type="range" id="quality" min="1" max="100" defaultValue="80" className="w-full h-2 bg-pf-bgLight rounded-lg appearance-none cursor-pointer accent-primary"/>
      </div>
       <div>
        <label htmlFor="guidance" className="block text-sm font-medium text-pf-textMedium mb-1">Guidance Scale: <span className="text-pf-textLight">9</span></label>
        <input type="range" id="guidance" min="1" max="20" defaultValue="9" className="w-full h-2 bg-pf-bgLight rounded-lg appearance-none cursor-pointer accent-primary"/>
      </div>
       <div>
        <label htmlFor="steps" className="block text-sm font-medium text-pf-textMedium mb-1">Steps: <span className="text-pf-textLight">45</span></label>
        <input type="range" id="steps" min="10" max="100" defaultValue="45" className="w-full h-2 bg-pf-bgLight rounded-lg appearance-none cursor-pointer accent-primary"/>
      </div> */}


      <button
        type="submit"
        disabled={isLoading || !prompt.trim()}
        className="w-full mt-6 inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-pf-textDark font-semibold py-3.5 px-6 rounded-lg shadow-md hover:shadow-xl transform hover:scale-105 transition-all duration-300 disabled:opacity-60 disabled:cursor-not-allowed text-base"
      >
        <SparklesIcon className="h-6 w-6" />
        {isLoading ? 'Generating Images...' : `Generate ${NUMBER_OF_IMAGES_TO_GENERATE} Images`}
      </button>
      <p className="text-xs text-pf-textMedium mt-2 text-center">
        Customize your image with styles, moods, lighting, and colors. Uses AI (Google Imagen) to create unique images.
      </p>
    </form>
  );
};