
import React from 'react';
import { AiCustomizationFilters, AiCustomizationFilterCategory, CustomizationOption, AiCustomizationCategory as CategoryDetails } from '../types';
import { AI_CUSTOMIZATION_CATEGORIES } from '../constants';

interface AiImageCustomizationPanelProps {
  selectedFilters: AiCustomizationFilters;
  onFilterChange: (category: AiCustomizationFilterCategory, value: string) => void;
}

const FilterButton: React.FC<{
  option: CustomizationOption;
  isSelected: boolean;
  onClick: () => void;
}> = ({ option, isSelected, onClick }) => {
  return (
    <button
      type="button"
      title={option.tooltip}
      onClick={onClick}
      className={`
        p-2 px-3 rounded-lg border text-sm transition-all duration-200 ease-in-out
        flex flex-col items-center justify-center space-y-1 min-w-[70px] sm:min-w-[80px] h-[70px] sm:h-[80px]
        focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-pf-bgMedium
        ${isSelected 
          ? 'bg-pf-accent text-pf-textDark border-pf-accentHover ring-2 ring-pf-accentHover shadow-lg scale-105' 
          : 'bg-pf-bgLight/70 text-pf-textMedium border-pf-borderMedium hover:bg-pf-accent/20 hover:border-pf-accent/70 hover:shadow-md dark:bg-pf-bgLight/70 dark:border-pf-borderMedium dark:hover:bg-pf-accent/20 dark:hover:border-pf-accent/70'
        }
      `}
    >
      <span 
        className={`text-2xl ${isSelected ? 'text-pf-textDark' : 'text-pf-textLight'}`} 
        role="img" 
        aria-label={option.name}
      >
        {option.icon || option.name.charAt(0)}
      </span>
      <span className={`truncate text-xs ${isSelected ? 'text-pf-textDark' : 'text-pf-textMedium'}`}>
        {option.name}
      </span>
    </button>
  );
};

export const AiImageCustomizationPanel: React.FC<AiImageCustomizationPanelProps> = ({
  selectedFilters,
  onFilterChange,
}) => {
  return (
    <div className="mt-6 space-y-6">
      {AI_CUSTOMIZATION_CATEGORIES.map((category: CategoryDetails) => (
        <div 
          key={category.id} 
          className="p-4 bg-pf-bgMedium/60 dark:bg-pf-bgMedium/60 backdrop-blur-sm border border-pf-borderLight/50 dark:border-pf-borderLight/50 rounded-xl shadow-lg"
        >
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-lg font-semibold text-pf-accent capitalize">
              {category.name}
            </h3>
            <button
                type="button"
                onClick={() => onFilterChange(category.id, '')}
                title={`Clear ${category.name} selection`}
                className="text-xs px-3 py-1 rounded-md border border-pf-borderMedium text-pf-textMedium hover:bg-pf-bgLight hover:border-pf-accent/50 transition-colors focus:outline-none focus:ring-1 focus:ring-pf-accent"
            >
                None
            </button>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2.5 sm:gap-3">
            {category.options.map((option) => (
              <FilterButton
                key={option.id}
                option={option}
                isSelected={selectedFilters[category.id] === option.id}
                onClick={() => onFilterChange(category.id, option.id)}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};
